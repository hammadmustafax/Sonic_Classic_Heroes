#pragma once
#include "Header.h"

class LeaderBoard {
private:
	bool backtoMenu;
	Sprite* backgroundSprite;
	Texture* backgroundTexture;

	int screen_x;
	int screen_y;

public:
	LeaderBoard(int screen_x, int screen_y);
	~LeaderBoard();

	void compareScores(int, string);

	void set_backtoMenu(bool);
	bool get_backtoMenu();

	void display(RenderWindow&);
	void handleInput(RenderWindow&, Event&);
};