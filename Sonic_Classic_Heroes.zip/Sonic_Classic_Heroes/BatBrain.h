#pragma once
#include "header.h"
#include "Enemy.h"

class BatBrain : public Enemy {
private:
	float bufferY = 0;

public:
	BatBrain() {

		numofAnimations = 3;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/BatBrainStill.png";
		paths[1] = "Data/BatBrainMovingLeft.png"; paths[2] = "Data/BatBrainMovingRight.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 64; totalWidth[1] = 576; totalWidth[2] = 576;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);

		isEnemyAttacking = false;
		enemySpeed = 4;
		isFacingRight = true;
		bufferY = enemyY;
		hp = 3;
		isEnemyActive = true;
	}

	void display(RenderWindow& window, float off) {
		if (isEnemyActive) {
			activeSprite->setPosition(enemyX - off, enemyY);
			window.draw(*activeSprite);
		}
	}

	void setEnemy(float regionLeft, float regionRight, float y) {

		this->regionLeft = regionLeft;
		this->regionRight = regionRight;
		enemyX = (regionRight - (regionRight - regionLeft) / 2) * cellSize;
		enemyY = y * cellSize;
		bufferY = enemyY;
	}

	void movement(float time) {

		if (isFacingRight) {
			if (enemyX + enemySpeed * time < regionRight * cellSize) {
				enemyX += enemySpeed * time / 30;
				isFacingRight = true;
				movementClock.restart();
			}
			else isFacingRight = false;
		}

		else if (!isFacingRight) {
			if (enemyX - enemySpeed * time > regionLeft * cellSize) {
				enemyX -= enemySpeed * time / 30;
				movementClock.restart();
				isFacingRight = false;
			}
			else isFacingRight = true;
		}

	}
	void attack(float time, float playerX, float playerY) {

		if ((enemyY + cellSize) < playerY) enemyY = bufferY + 64;

		if (playerX < enemyX) {
			enemyX -= enemySpeed * time / 30; isFacingRight = false;
		}
		else if (playerX > enemyX) {
			enemyX += enemySpeed * time / 30; isFacingRight = true;
		}
	}

	void update(float time, float playerX = 0, float playerY = 0 , int** grid = nullptr , int vol = 0) {

		EnemyKill.setVolume(vol);

		if ((playerX >= regionLeft * cellSize) && (playerX <= regionRight * cellSize)) {
			isEnemyAttacking = true;
			attack(time, playerX, playerY);
		}
		else {
			isEnemyAttacking = false;
			movement(time);
		}

		if (isEnemyAttacking == false) {
			enemyY = bufferY;
		}
	}

	void animate(float off) {

		if (!isEnemyActive) return;
		for (int i = 0; i < numofAnimations; i++) conditionsforAnimations[i] = false;

		if (!isEnemyAttacking) conditionsforAnimations[0] = true;
		else if (!isFacingRight) conditionsforAnimations[1] = true;
		else conditionsforAnimations[2] = true;

		activeSprite = animation->animate(off, enemyX, enemyY);
	}
};