#pragma once
#include "header.h"
#include "Enemy.h"

class CrabMeat : public Enemy {
private:
	Texture bulletTexture;
	Sprite bulletSprite;
	bool isBulletActive[2];
	int bulletSize = 16;
	float bulletX[2]; float velocityX[2];
	float bulletY[2]; float velocityY[2];
	float bulletSpeed; float bulletGravity;
	bool bulletJustStarted = true;

public:
	CrabMeat() {
		
		numofAnimations = 2;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/CrabMeatWalking.png"; paths[1] = "Data/CrabMeatAttacking.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 448; totalWidth[1] = 192;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);

		bulletTexture.loadFromFile("Data/CrabMeatBullet.png");
		bulletSprite.setTexture(bulletTexture);

		hp = 4;

		enemySpeed = 4;
		currentX = 0;

		bulletSpeed = 15;
		bulletGravity = 2;
		isBulletActive[0] = false; isBulletActive[1] = false;
	}

	void movement(float time) {

		if (attackClock.getElapsedTime().asSeconds() > 3) { isEnemyAttacking = true; attackClock.restart(); return; }

		if (isFacingRight && movementClock.getElapsedTime().asSeconds() > 0.4) {
			if (enemyX + enemySpeed * time < regionRight * cellSize) {
				enemyX += enemySpeed * time;
				movementClock.restart();
			}
			else isFacingRight = false;
		}

		else if (!isFacingRight && movementClock.getElapsedTime().asSeconds() > 0.4) {
			if (enemyX - enemySpeed * time > regionLeft * cellSize) {
				enemyX -= enemySpeed * time;
				movementClock.restart();
			}
			else isFacingRight = true;
		}
	}

	void attack(float time, float playerX, float playerY) {

		if (attackClock.getElapsedTime().asSeconds() > 2) {
			isEnemyAttacking = false;
			bulletJustStarted = true;

			isBulletActive[0] = true; isBulletActive[1] = true;
			attackClock.restart();
			return;
		}

		if (bulletJustStarted) {
			bulletX[0] = enemyX - 15; bulletY[0] = enemyY - 10;
			bulletX[1] = enemyX + 45; bulletY[1] = enemyY - 10;

			velocityX[0] = -1 * bulletSpeed; velocityX[1] = 1 * bulletSpeed;
			velocityY[0] = velocityY[1] = -5;

			bulletJustStarted = false;
		}

		for (int i = 0; i < 2; i++) {

			bulletX[i] += velocityX[i] * time / 30;
			bulletY[i] += velocityY[i] * time / 30;
			
			velocityY[i] += bulletGravity * time / 30;

			if (bulletX[i] < regionLeft * cellSize || bulletX[i] > regionRight * cellSize) {
				isBulletActive[i] = false;
			}
		}
	}

	void display(RenderWindow& window, float off) {
		if (isEnemyActive) {

			activeSprite->setPosition(enemyX - off, enemyY);
			window.draw(*activeSprite);

			if (isEnemyAttacking) {
				for (int i = 0; i < 2; i++) {
					if (isBulletActive[i]) {
						bulletSprite.setPosition(bulletX[i] - off, bulletY[i]);
						window.draw(bulletSprite);
					}
				}
			}
		}
	}

	void update(float time, float playerX = 0, float playerY = 0 , int** grid = nullptr , int vol = 0) {
		
		EnemyKill.setVolume(vol);
		bulletCollision = false;

		if (isEnemyAttacking) {
			attack(time, playerX, playerY);
			for (int i = 0; i < 2; i++) {
				if (collision1D(bulletY[i], bulletSize, enemyY + cellSize, cellSize)) isBulletActive[i] = false;
			}
		}
		else movement(time);
	}

	void animate(float off) {

		if (!isEnemyActive) return;
		for (int i = 0; i < numofAnimations; i++) conditionsforAnimations[i] = false;

		if (isEnemyAttacking) conditionsforAnimations[1] = true;
		else conditionsforAnimations[0] = true;

		activeSprite = animation->animate(off, enemyX, enemyY);
	}

	bool collision2D(float playerX, float playerY, bool isRollingState, int& score) {
		bool collisionX = (playerX + cellSize >= enemyX && enemyX + cellSize >= playerX);
		bool collisionY = (playerY + cellSize >= enemyY && enemyY + cellSize >= playerY);

		if (collisionX && collisionY) {
			return true;
		}
		else {
			for (int i = 0; i < 2; i++) {
				bool bulletCollisionX = (playerX + cellSize >= bulletX[i] && bulletX[i] + cellSize >= playerX);
				bool bulletCollisionY = (playerY + cellSize >= bulletY[i] && bulletY[i] + cellSize >= playerY);
			
				if (bulletCollisionX && bulletCollisionY && collisionClock.getElapsedTime().asMilliseconds() > 1200) {
					collisionClock.restart();
					bulletCollision = true;
					return true;
				}
			}
		}
		return false;
	}
};