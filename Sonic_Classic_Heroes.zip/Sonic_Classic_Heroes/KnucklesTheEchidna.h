#pragma once
#include "Header.h"
#include "Player.h"

class KnucklesTheEchidna : public Player {
public:
	KnucklesTheEchidna(bool isPlayerActive) : Player(isPlayerActive) {

		numofAnimations = 8;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/KnucklesIdleLeft.png"; paths[1] = "Data/KnucklesIdleRight.png";
		paths[2] = "Data/KnucklesWalkLeft.png"; paths[3] = "Data/KnucklesWalkRight.png";
		paths[4] = "Data/KnucklesJumpLeft.png"; paths[5] = "Data/KnucklesJumpRight.png";
		paths[6] = "Data/KnucklesPunchLeft.png"; paths[7] = "Data/KnucklesPunchRight.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 64; totalWidth[1] = 64; totalWidth[2] = 512; totalWidth[3] = 512;
		totalWidth[4] = 512; totalWidth[5] = 512; totalWidth[6] = 320; totalWidth[7] = 320;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);

		speed = 12; 
	}

	void update(float time, int** grid, float friction, int volume , float gravity) {

		isPlayerMoving = false;

		if (Keyboard::isKeyPressed(Keyboard::Right)) MoveRight(time, friction);
		if (Keyboard::isKeyPressed(Keyboard::Left)) MoveLeft(time, friction);
		if (Keyboard::isKeyPressed(Keyboard::Space)) {
			if (!isPlayerJumping && onGround && jumpTimer.getElapsedTime().asSeconds() > 0.1) { jumpTimer.restart(); onGround = false; isPlayerJumping = true; velocityY = jump_offset; jumpMusic.play(); }
		}

		specialAbility(time, grid);
	}

	void specialAbility(float time, int** grid) {

		int lcollision = grid[(int)((playerY + cellsize / 2) / cellsize)][(int)((playerX - 1) / cellsize)];
		int rcollision = grid[(int)((playerY + cellsize / 2) / cellsize)][(int)((playerX + cellsize + 1) / cellsize)];

		if (rcollision == 3 || lcollision == 3) {

			if (!isSpecialAbilityActive) {
				isSpecialAbilityActive = true;
				specialAbilityClock.restart();
			}

			if (isSpecialAbilityActive && specialAbilityClock.getElapsedTime().asSeconds() > 1) {
				if (rcollision == 3) {
					grid[(int)((playerY + cellsize / 2) / cellsize)][(int)((playerX + cellsize + 1) / cellsize)] = 0;
				}
				if (lcollision == 3) {
					grid[(int)((playerY + cellsize / 2) / cellsize)][(int)((playerX - 1) / cellsize)] = 0;
				}
				isSpecialAbilityActive = false;
			}
		}
	}
};