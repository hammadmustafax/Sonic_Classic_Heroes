#pragma once
#include "Header.h"
#include "Player.h"

class TailsTheFox : public Player {
private:
	float flySpeed = -5; // Upward speed for flying
	bool flyingCoolDown;
	Clock flyTimer;
	
public:
	TailsTheFox(bool isPlayerActive, bool spaceAlreadyPressed = false) : Player(isPlayerActive) {

		numofAnimations = 8;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/TailsIdleLeft.png"; paths[1] = "Data/TailsIdleRight.png";
		paths[2] = "Data/TailsWalkLeft.png"; paths[3] = "Data/TailsWalkRight.png";
		paths[4] = "Data/TailsJumpLeft.png"; paths[5] = "Data/TailsJumpRight.png";
		paths[6] = "Data/TailsFlyingLeft.png"; paths[7] = "Data/TailsFlyingRight.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 64; totalWidth[1] = 64; totalWidth[2] = 512; totalWidth[3] = 512;
		totalWidth[4] = 256; totalWidth[5] = 256; totalWidth[6] = 512; totalWidth[7] = 512;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);

		speed = 10;
		this->spaceAlreadyPressed = spaceAlreadyPressed;
		flyingCoolDown = false;
	}

	bool getSpaceAlreadyPressed() {
		return spaceAlreadyPressed;
	}

	void update(float time, int** grid, float friction, int volume , float gravity) {

		isPlayerMoving = false;

		if (Keyboard::isKeyPressed(Keyboard::Right)) MoveRight(time, friction);
		if (Keyboard::isKeyPressed(Keyboard::Left)) MoveLeft(time, friction);

		bool spaceIsPressed = (Keyboard::isKeyPressed(Keyboard::Space));
		bool spaceJustPressed = spaceIsPressed && !spaceAlreadyPressed;
		spaceAlreadyPressed = spaceIsPressed;

		if (spaceJustPressed) {
			if (onGround && jumpTimer.getElapsedTime().asSeconds() > 0.1) {
				jumpTimer.restart();
				isPlayerJumping = true;
				onGround = false;
				velocityY = jump_offset;
				isSpecialAbilityActive = false;
				flyingCoolDown = false;
				flyTimer.restart();

			}
			else if (isPlayerJumping && !isSpecialAbilityActive) {
				isSpecialAbilityActive = true;
				specialAbilityClock.restart();
			}
		}

		if (!onGround) {
			if (flyTimer.getElapsedTime().asSeconds() >= maxFlyTime) {
				flyingCoolDown = true;
				isSpecialAbilityActive = false;

				velocityY += gravity * time / 30; 
				if (velocityY > terminal_Velocity) velocityY = terminal_Velocity;
			}
		
			else if (isSpecialAbilityActive && spaceIsPressed && specialAbilityClock.getElapsedTime().asSeconds() <= maxFlyTime && !flyingCoolDown) {
				if (!topcollision) velocityY = flySpeed;
				else velocityY = 0;
			}
			
			else if (!flyingCoolDown) {
				if (isSpecialAbilityActive && !spaceIsPressed) isSpecialAbilityActive = false;
				velocityY += gravity * time / 30;
				if (velocityY > terminal_Velocity) velocityY = terminal_Velocity;
			}
		}

		else {
			flyingCoolDown = false;
		}

		int x_axis = (int)(playerY - 1) / cellsize;
		int y_axis = (int)(playerX + cellsize / 2) / cellsize;
		int tcollision = -1;

		if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth) {
			tcollision = grid[x_axis][y_axis];
		}

		if (tcollision == 1 || tcollision == 3 || tcollision == -1) {
			if (velocityY < 0) velocityY = 0;
			topcollision = true;
		}
		else topcollision = false;

		float tempY = playerY + velocityY * time / 30;
		if (tempY >= 0) playerY = tempY;
		else {
			playerY = 0;
			velocityY = 0;
		}

		player_gravity(grid , gravity);

		if (bottomcollision) {
			isSpecialAbilityActive = false;
			isPlayerJumping = false;
			onGround = true;
			flyingCoolDown = false;
		}
		else if (isSpecialAbilityActive && specialAbilityClock.getElapsedTime().asSeconds() >= maxFlyTime) {
			isSpecialAbilityActive = false;
		}
	}

	void handleUpdate(float time, int** grid, float friction, int volume, float offset , float gravity) {
		
		if (collisionTimer.getElapsedTime().asSeconds() > 1) {
			isHit = false;
		}

		jumpMusic.setVolume(volume);
		playerDamage.setVolume(volume);

		update(time, grid, friction, volume , gravity);
		player_gravity(grid , gravity);
		animate(offset);
	}
};