#pragma once
#include "Level.h"
#include "Player.h"
#include "Header.h"

class LabyrinthZone : public Level {
private:
	int levelNumber;
	void makeMap();
	void deployCollectibles();
	void deployEnemies();
	void levelTriggers();

public:
	LabyrinthZone(int, Player*, Player*, Player*);
	~LabyrinthZone();
};