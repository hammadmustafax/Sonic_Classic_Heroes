#include "BossLevel.h"
#include "Header.h"

BossLevel::BossLevel(int levelNumber, Player* player1) :Level(levelNumber, player1) {

	gravity = 1;
	friction = 0.98;

	this->levelNumber = levelNumber;
	cols = 20;
	grid = new int* [rows]; for (int i = 0; i < rows; i++) grid[i] = new int[cols];

	eggStinger = new Enemy*;
	eggStinger[0] = new EggStinger;

	backgroundTexture.loadFromFile("Data/background4.png");
	backgroundSprite.setTexture(backgroundTexture);

	brick1Texture.loadFromFile("Data/extraBrick.png"); brick1Sprite.setTexture(brick1Texture);

	LevelMusic.openFromFile("Music/Level4.mp3");
	LevelMusic.setLoop(true);
	LevelMusic.play();

	makeMap();
}

BossLevel::~BossLevel() {
	for (int i = 0; i < rows; i++) delete[]grid[i];
	delete[]grid; grid = nullptr;
}

void BossLevel::makeMap() {

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			grid[i][j] = 0;
		}
	}

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			if (i == 11) { grid[i][j] = 1; }
		}
	}
}
void BossLevel::levelTriggers()
{
	;
}