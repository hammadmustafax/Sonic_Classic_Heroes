#pragma once
#include "MainMenu.h"
#include "Options.h"
#include "LeaderBoard.h"
#include "Level.h"
#include "Player.h"
#include "Header.h"

class Game {
private:
	MainMenu* mainMenu;
	Options* options;
	LeaderBoard* leaderBoard;
	
	Player* sonic;
	Player* tails;
	Player* knuckles;

	Level* level;

	Texture* wonOrLostTexture;
	Sprite* wonOrLostSprite;
	Clock wonOrLostClock;

	string playerName;
	int score;
	int volume;

	int levelNumber;
	bool isGameStart;

	int screen_x;
	int screen_y;

	bool islevelLost;
	bool loadNextLevel;
	bool takeNameInput;
	bool takeOldState;

	void loadLevel();
public:
	Game(int screen_x, int screen_y);
	~Game();

	void retrieveGame();
	void saveGame();
	void saveLevel(fstream&, Level*);
	void saveCharacters(fstream&, Player*);

	bool get_exitGame();
	void set_exitGame(bool);
	bool getIsLevelLost() {
		return islevelLost;
	}
	bool getIsGameStart() {
		return isGameStart;
	}

	void wonOrLostDisplay(bool, RenderWindow&);

	void handleInput(RenderWindow&, Event&, float);
	void update(float time);
	void display(RenderWindow&);
};