//Newer Version Sent by Hammad

#pragma once
#include "header.h"
#include "Enemy.h"

class EggStinger : public Enemy {
private:

	Sprite stingSprite;
	Texture stingTexture;

	float VelocityY;
	float gravity;
	bool leftCollision;
	bool rigthCollision; 
	float orignalposition = 128;
	bool bottomCollision = false, isReturn = false;
	bool isReceivingDamage = false;
	float targetX;

public:
	EggStinger() {

		numofAnimations = 6;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/BossMovingLeft1.png"; paths[1] = "Data/BossMovingRight1.png";
		paths[2] = "Data/BossDamagingLeft1.png"; paths[3] = "Data/BossDamagingRight1.png";
		paths[4] = "Data/BossReceivingDamageLeft1.png"; paths[5] = "Data/BossReceivingDamageRight1.png";

		int* totalWidth = new int[numofAnimations]; enemyWidth = 128; enemyHeight = 64;
		totalWidth[0] = 256; totalWidth[1] = 256; totalWidth[2] = 256;
		totalWidth[3] = 256; totalWidth[4] = 384; totalWidth[5] = 384;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, enemyWidth, totalWidth, condition, enemyHeight);

		stingTexture.loadFromFile("Data/Sting.png");
		stingSprite.setTexture(stingTexture);

		enemyX = 10 * 64;
		enemyY = 128;
		enemySpeed = 12;
		VelocityY = 0;
		gravity = 1;
		rigthCollision = false;
		leftCollision = true;
		cellSize = 64;
		isEnemyActive = true;
		isEnemyAttacking = false;
		hp = 20;
	}

	void display(RenderWindow& window, float off) {
		if (isEnemyActive) {
			activeSprite->setPosition(enemyX, enemyY);
			if (isEnemyAttacking) window.draw(stingSprite);
			window.draw(*activeSprite);
		}
	}

	void movement(float time)
	{
		if (leftCollision == false)  // Move left
		{
			if (enemyX > 0) {
				enemyX -= enemySpeed * time / 30;
				stingSprite.setPosition(enemyX + 45, enemyY + enemyHeight);
			}
			else {
				leftCollision = true;
				rigthCollision = false;
			}
		}
		else if (rigthCollision == false) {
			if (enemyX < 20 * cellSize - enemyWidth) {
				enemyX += enemySpeed * time / 30;
				stingSprite.setPosition(enemyX + 35, enemyY + enemyHeight);
			}
			else {
				rigthCollision = true;
				leftCollision = false;
			}
		}
	}

	void attack(float time, float playerX, float playerY) {

		if (!isEnemyAttacking && attackClock.getElapsedTime().asSeconds() > 10) {
			isEnemyAttacking = true;
			targetX = playerX;
			isReturn = false;
			VelocityY = 0;
		}

		if (!isEnemyAttacking) return;

		if (!isReturn) {
			if (enemyX < targetX - 10) {
				enemyX += enemySpeed * time / 30;
			}
			else if (enemyX > targetX + 10) {
				enemyX -= enemySpeed * time / 30;
			}
			if ((enemyY + VelocityY + gravity) <= 13 * cellSize - 32) {
				VelocityY += gravity;
				enemyY += VelocityY * time / 100;
				revertMovement(time);
			}
			if (bottomCollision || ((enemyY + VelocityY + gravity) >= 13 * cellSize - 32)) {
				isReturn = true;
				VelocityY = -20;
			}
		}

		else {
			VelocityY += gravity;
			enemyY -= VelocityY * time / 100;
			revertMovement(time);

			if (enemyY <= orignalposition)
			{
				enemyY = orignalposition;
				VelocityY = 0;
				isEnemyAttacking = false;
				isReturn = false;
				attackClock.restart(); // Restart cooldown
			}
		}
	}

	void Collision(int** grid) {
		if (grid == nullptr)
			return;

		int bottom_collision_left = grid[(int)(enemyY +/* hit_box_factor_y +*/ cellSize) / cellSize][(int)(enemyX /*+ hit_box_factor_x*/) / cellSize];
		int bottom_collision_right = grid[(int)(enemyY + /*hit_box_factor_y +*/ cellSize) / cellSize][(int)(enemyX + /*hit_box_factor_x + */cellSize) / cellSize];
		int bottom_collision_mid = grid[(int)(enemyY + /*hit_box_factor_y +*/ cellSize) / cellSize][(int)(enemyX + /*hit_box_factor_x + */cellSize / 2) / cellSize];

		if (bottom_collision_left == 1 || bottom_collision_mid == 1 || bottom_collision_right == 1) {
			grid[(int)(enemyY + /*hit_box_factor_y + */cellSize) / cellSize][(int)(enemyX + /*hit_box_factor_x + */cellSize / 2) / cellSize] = 0;
			bottomCollision = true;
			VelocityY = 0;
		}
		else bottomCollision = false;
	}

	void update(float time, float playerX = 0, float playerY = 0, int** grid = nullptr, int vol = 0) {
		movement(time);
		Collision(grid);
		attack(time, playerX, playerY);
	}

	void revertMovement(float time) {

		if (leftCollision == false) {
			if (enemyX < 20 * cellSize - enemyWidth) {
				enemyX += enemySpeed * time / 30;
				stingSprite.setPosition(enemyX + 35, enemyY + enemyHeight);
			}
			else {
				leftCollision = true;
				rigthCollision = false;
				stingSprite.setPosition(enemyX + 45, enemyY + enemyHeight);
			}
		}
		else if (rigthCollision == false) {
			if (enemyX > 0) {
				enemyX -= enemySpeed * time / 30;
			}
			else {
				rigthCollision = true;
				leftCollision = false;
			}
		}
	}

	bool collision2D(float playerX, float playerY, bool isRollingState, int& score) {
		bool collisionX = (playerX + cellSize >= enemyX && enemyX + enemyWidth >= playerX);
		bool collisionY = (playerY + cellSize >= enemyY && enemyY + enemyHeight >= playerY);

		if (movementClock.getElapsedTime().asSeconds() > 0.5) isReceivingDamage = false;

		if (collisionX && collisionY) {
			return true;
		}
		return false;
	}

	void animate(float off) {
		if (!isEnemyActive) return;
		for (int i = 0; i < numofAnimations; i++) conditionsforAnimations[i] = false;

		if (!leftCollision) {
			if (isReceivingDamage) conditionsforAnimations[4] = true;
			else if (isEnemyAttacking) conditionsforAnimations[2] = true;
			else conditionsforAnimations[0] = true;
		}
		else {
			if (isReceivingDamage) conditionsforAnimations[5] = true;
			else if (isEnemyAttacking) conditionsforAnimations[3] = true;
			else conditionsforAnimations[1] = true;
		}
		activeSprite = animation->animate(off, enemyX, enemyY);
	}
};