#pragma once
#include "Header.h"
#include "Enemy.h"

class MotoBug : public Enemy{
public:
	MotoBug() {

		hp = 2;
		isFacingRight = true;
		isEnemyAttacking = false;
		isEnemyActive = true;
		enemySpeed = 4;

		numofAnimations = 2;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/MotobugMoveLeft.png"; paths[1] = "Data/MotobugMoveRight.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 384; totalWidth[1] = 384;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);

		currentX = 0;
	}

	void display(RenderWindow& window, float off) {
		if (isEnemyActive) {
			activeSprite->setPosition(enemyX - off, enemyY);
			window.draw(*activeSprite);
		}
	}

	void setEnemy(float regionLeft, float regionRight, float y) {
		this->regionLeft = regionLeft;
		this->regionRight = regionRight;
		enemyX = (regionRight - (regionRight - regionLeft) / 2) * cellSize;
		enemyY = y * cellSize;
	}

	void movement(float time) {

		if (isFacingRight && movementClock.getElapsedTime().asSeconds() > 0.4) {
			if (enemyX + enemySpeed * time < regionRight * cellSize) {
				enemyX += enemySpeed * time;
				movementClock.restart();
			}
			else isFacingRight = false;
		}

		else if (!isFacingRight && movementClock.getElapsedTime().asSeconds() > 0.4) {
			if (enemyX - enemySpeed * time > regionLeft * cellSize) {
				enemyX -= enemySpeed * time;
				movementClock.restart();
			}
			else isFacingRight = true;
		}
	}

	void attack(float time, float playerX, float playerY) {

		if (playerX < enemyX) {
			enemyX -= enemySpeed * time / 30;
			isFacingRight = false;
		}
		else if (playerX > enemyX) {
			enemyX += enemySpeed * time / 30;
			isFacingRight = true;
		}
	}

	void update(float time, float playerX = 0, float playerY = 0 , int** grid = nullptr , int vol = 0) {
		EnemyKill.setVolume(vol);
		if ((playerX >= regionLeft * cellSize) && (playerX <= regionRight * cellSize)) {
			attack(time, playerX, playerY);
		}
		else {
			movement(time);
		}
	}

	void animate(float off) {

		if (!isEnemyActive) return;
		for (int i = 0; i < numofAnimations; i++) conditionsforAnimations[i] = false;

		if (!isFacingRight) conditionsforAnimations[0] = true;
		else conditionsforAnimations[1] = true;

		activeSprite = animation->animate(off, enemyX, enemyY);
	}
};