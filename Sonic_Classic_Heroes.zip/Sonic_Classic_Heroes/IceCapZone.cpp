#include "IceCapZone.h"
#include "Header.h"
#include "MotoBug.h"
#include "BeeBot.h"
#include"ExtraLives.h"
#include"SpecialBoost.h"

IceCapZone::IceCapZone(int levelNumber, Player* player1, Player* player2, Player* player3) :Level(levelNumber, player1, player2, player3) {

	levelTime = 150;
	friction = 0.95;
	gravity = 1;

	numofRings = 35;
	ringsLeft = numofRings;
	rings = new Rings[numofRings];

	numofExtraLives = 2;
	extraLives = new ExtraLives[numofExtraLives];

	numofSpecialBoosts = 2;
	specialBoost = new SpecialBoost[numofSpecialBoosts];

	onbreakable = false;

	this->levelNumber = levelNumber;
	cols = 250;
	grid = new int* [rows]; for (int i = 0; i < rows; i++) grid[i] = new int[cols];

	numOfBeeBot = 3;
	numOfMotoBug = 3;

	motoBug = new Enemy*[numOfMotoBug]; for (int i = 0; i < numOfMotoBug; i++) motoBug[i] = new MotoBug;
	beeBot = new Enemy*[numOfBeeBot];   for (int i = 0; i < numOfBeeBot; i++) beeBot[i] = new BeeBot;

	backgroundTexture.loadFromFile("Data/background2.png");
	backgroundSprite.setTexture(backgroundTexture);

	brick1Texture.loadFromFile("Data/brick21.png"); brick1Sprite.setTexture(brick1Texture);
	brick2Texture.loadFromFile("Data/brick22.png"); brick2Sprite.setTexture(brick2Texture);
	brick3Texture.loadFromFile("Data/brick23.png"); brick3Sprite.setTexture(brick3Texture);

	bridgeTexture.loadFromFile("Data/bridge2.png"); bridgeSprite.setTexture(bridgeTexture);
	switchTexture.loadFromFile("Data/switch2.png"); switchSprite.setTexture(switchTexture);

	spikeTexture.loadFromFile("Data/spike.png");
	spikeSprite.setTexture(spikeTexture);

	LevelMusic.openFromFile("Music/level2.mp3");
	LevelMusic.setLoop(true);
	LevelMusic.play();

	makeMap();
	deployCollectibles();
	deployEnemies();
}
IceCapZone::~IceCapZone() {
	for (int i = 0; i < rows; i++) delete[]grid[i];
	delete[]grid; grid = nullptr;
}

void IceCapZone::makeMap() {

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			grid[i][j] = 0;
		}
	}

	//Labyrinth Zone has 200 columns and if we make a section of 20 columns then only 10 sections are required

	//Block 1 is for ground
	//Block 2 is for breakable wall
	//Block 3 is for platforms not on ground
	//Block 4 is for bridge
	//Block 5 is for switch
	//Block 6 is for gate
	//Block 7 is just for occupying space
	//Block 8 is for end of level

	//Section 1: 0-20 columns:




	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < 20; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i < 2) { if (j > 4) grid[i][j] = 1; }
			else if (i < 5) { if (j > 13) grid[i][j] = 1; }
			else  if (i < 6) { if (j > 9) grid[i][j] = 1; }
			else if (i == 8) { if ((j > 7) && (j < 10)) grid[i][j] = 2; }
			else if (i == 9) { if (j < 2) grid[i][j] = 1; }
			else if (i == 10) { if (j < 5) grid[i][j] = 1; }
			else if (i > 10) {
				if ((j > 7) && (j < 10))   grid[i][j] = 0;
				else grid[i][j] = 1;
			}
		}
	}

	//Section 02: 20-40 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 20; j < 40; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i <= 6) {
				if (j == 26) grid[i][j] = 1; else grid[i][j] = 0;
				if (i == 6 && j > 22 && j < 26) grid[i][j] = 1;
				if (j == 36) grid[i][j] = 1;
				if (j == 39) grid[i][j] = 1;

			}
			else if (i >= 7 && i < 9)
			{
				if (i == 7) continue;
				if (j >= 35 && j <= 39) grid[i][j] = 1;

			}
			else if (i == 9)
			{
				if (j > 20 && j < 27) grid[i][j] = 2;
				if (j == 36) grid[i][j] = 3;
				if (j == 39) grid[i][j] = 3;
			}


			else if (i >= 10)
			{
				if (j > 27) grid[i][j] = 1; else grid[i][j] = 0;
			}

		}
	}

	//Section 03: 40-60 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 40; j < 60; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i < 3) { if (j < 43) grid[i][j] = 1; }
			else if (i < 7) { if (j >= 48 && j <= 51) grid[i][j] = 1; }
			else if (i == 12) { if (j >= 48 && j < 52) grid[i][j] = 1; else grid[i][j] = 4; }
		}
	}

	//Section 04: 60-80 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 60; j < 80; j++) {

			if (i == 0) grid[i][j] = 1;
			if (i <= 7)
			{
				if (i > 3)
				{
					if (j == 61) grid[i][j] = 1;
					if (j == 78) grid[i][j] = 1;
				}
				if (i < 2 || i > 5)
				{
					if (j == 65 || j == 74)  grid[i][j] = 1;
					if (i == 6 && ((j > 61 && j < 65) || (j > 74 && j < 78))) grid[i][j] = 1;
				}
				else
				{
					if (i != 3 && i!=4 && j >= 65 && j <= 74) grid[i][j] = 1;
				}
			}

			if (i >= 10) grid[i][j] = 1;
		}
	}

	//Section 05: 80-100 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 80; j < 100; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i < 2) {
				if (j > 87 && j < 91) grid[i][j] = 1;
			}
			if (i == 2) {
				if (j > 83 && j <= 86) grid[i][j] = 2;
			}
			else if (i == 6) {
				if (j > 80 && j <= 83) grid[i][j] = 2;
				if (j > 87 && j < 91) grid[i][j] = 1;
			}
			else if (i < 9) {
				if (i != 8) {
					if (j > 87 && j < 91) grid[i][j] = 1;
				}
				else { if (j > 87 && j < 91 && j != 89) grid[i][j] = 3; }
			}
			else if (i >= 9) {
				grid[i][j] = 1;
			}
		}
	}

	//Section 06: 100-120 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 100; j < 120; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i == 4) {
				if (j > 110 && j < 114) grid[i][j] = 2;
			}
			else if (i == 6) {
				if (j > 105 && j < 108) grid[i][j] = 2;
				if (j > 115 && j < 118) grid[i][j] = 2;
			}
			else if (i == 8) {
				if (j > 104 && j < 116) grid[i][j] = 8;
			}
			else if ((i == 9 || i == 10) && ((j >= 100 && j <= 102) || (j >= 117 && j <= 119))) grid[i][j] = 1;
			else if (i == 9 || i == 10) grid[i][j] = 2; //I have to make this 0 or remove this
		}
	}

	//Section 07: 120-140 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 120; j < 140; j++) {
			if (i == 0) grid[i][j] = 1;
			else if (i == 9) { if (j == 120) grid[i][j] = 5; else if (j == 121) grid[i][j] = 7; else grid[i][j] = 1; }
			else if (i == 8) continue;
			else grid[i][j] = 1;
		}
	}
	grid[8][139] = 6; //gate

	//Section 08: 140-160 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 140; j < 160; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i == 9)
			{
				if (j == 140) grid[i][j] = 5 ;
			}

			else if (i == 10) {
				if (j >= 140 && j < 142) grid[i][j] = 1;
				if (j == 144 || j == 147 || j == 150 || j == 153 || j == 156 || j == 159) grid[i][j] = 1;
			}
			else if (i > 10 && i < 142) {
				if (j == 144 || j == 147 || j == 150 || j == 153 || j == 156 || j == 159) grid[i][j] = 1;

			}
			else if (i == 12) {
				if (j == 144 || j == 147 || j == 150 || j == 153 || j == 156 || j == 159) grid[i][j] = 1;
			}
		}
	}

	//Section 09: 160-180 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 160; j < 180; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i == 8) {
				grid[i][j] = 2;
			}
		}
	}

	//Section 10: 180-200 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 180; j < 200; j++) {
			if (i == 0) grid[i][j] = 1;
			else if (i > 10) grid[i][j] = 1;
			else if (i > 9) { if (j > 182) grid[i][j] = 1; }
			else if (i > 8) { if (j > 185) grid[i][j] = 1; }
			else if (i > 7) { if (j > 186) grid[i][j] = 1; }
			else if (i > 6) { if (j > 190) grid[i][j] = 1; }
			else if (i > 5) { if (j > 192) grid[i][j] = 1; }
		}
	}
	for (int i = 0; i < rows; i++) {
		for (int j = 200; j < 220; j++) {

			if (i == 0) grid[i][j] = 0;
			else if (i == 12) {

				if ((j >= 200 && j < 208) || (j > 210 && j < 220))
					grid[i][j] = 1;
			}
			else if (i == 11) {
				if ((j >= 200 && j < 207) || (j > 211 && j < 220))
					grid[i][j] = 1;
			}
			else if (i == 10) {
				if ((j >= 200 && j < 206) || (j > 212 && j < 220))
					grid[i][j] = 1;
			}
			else if (i == 9) {
				if ((j >= 200 && j < 205) || (j > 213 && j < 220))
					grid[i][j] = 1;
			}
		}
	}

	for (int i = 0; i < rows; i++) {
		for (int j = 220; j < 240; j++) {


			if (i == 0) grid[i][j] = 1;

			else if (i == 1) {
				if (j == 230) grid[i][j] = 3;
			}
			else if (i > 1 && i < 9) {
				if (j == 230) grid[i][j] = 3;
			}
			else if (i == 9) {
				if (j > 228 && j < 233) grid[i][j] = 2;
			}
			else if (i == 11) {
				if (j > 224 && j < 227) grid[i][j] = 2;
				if (j > 235 && j < 238) grid[i][j] = 2;
			}
			else if (i == 12) {
				if (j > 220 && j < 223) grid[i][j] = 2;
			}

		}
	}
	for (int i = 0; i < rows; i++) {
		for (int j = 240; j < 250; j++) {
			if (i > 10) grid[i][j] = 1;
		}
	}
	//Section 11: 200-220 columns:
	//Section 12: 220-240 columns:
	//Section 13: 240-250 columns:
}
void IceCapZone::deployCollectibles() {

	rings[0].setPosition(11 * cellSize, 3 * cellSize);
	rings[1].setPosition(11 * cellSize, 4 * cellSize);
	rings[2].setPosition(12 * cellSize, 3 * cellSize);
	rings[3].setPosition(12 * cellSize, 4 * cellSize);
	rings[4].setPosition(25 * cellSize, 4 * cellSize);

	rings[5].setPosition(24 * cellSize, 3 * cellSize);
	rings[6].setPosition(23 * cellSize, 4 * cellSize);
	rings[7].setPosition(37 * cellSize, 9 * cellSize);
	rings[8].setPosition(38 * cellSize, 9 * cellSize);

	rings[9].setPosition(63 * cellSize, 4 * cellSize);
	rings[10].setPosition(64 * cellSize, 4 * cellSize);
	rings[11].setPosition(69 * cellSize, 3 * cellSize);
	rings[12].setPosition(72 * cellSize, 3 * cellSize);
	rings[13].setPosition(75 * cellSize, 4 * cellSize);
	rings[14].setPosition(77 * cellSize, 4 * cellSize);

	rings[15].setPosition(144 * cellSize, 8 * cellSize);
	rings[16].setPosition(147 * cellSize, 9 * cellSize);
	rings[17].setPosition(150 * cellSize, 9 * cellSize);
	rings[18].setPosition(153 * cellSize, 9 * cellSize);
	rings[19].setPosition(89 * cellSize, 8 * cellSize);

	rings[20].setPosition(156 * cellSize, 6 * cellSize);
	rings[21].setPosition(159 * cellSize, 6 * cellSize);

	rings[22].setPosition(162 * cellSize, 6 * cellSize);
	rings[23].setPosition(165 * cellSize, 6 * cellSize);
	rings[24].setPosition(168 * cellSize, 6 * cellSize);
	rings[25].setPosition(171 * cellSize, 6 * cellSize);
	rings[26].setPosition(177 * cellSize, 6 * cellSize);

	rings[27].setPosition(207 * cellSize, 11 * cellSize);
	rings[28].setPosition(212 * cellSize, 10 * cellSize);
	rings[29].setPosition(235 * cellSize, 7 * cellSize);


	rings[30].setPosition(226 * cellSize, 10 * cellSize);
	rings[31].setPosition(229 * cellSize, 8 * cellSize);
	rings[32].setPosition(232 * cellSize, 8 * cellSize);
	rings[33].setPosition(244 * cellSize, 7 * cellSize);
	rings[34].setPosition(245 * cellSize, 6 * cellSize);

	specialBoost[0].setPosition(48 * cellSize, 8 * cellSize);
	specialBoost[1].setPosition(150 * cellSize, 7 * cellSize);

	extraLives[0].setPosition(70 * cellSize, 6 * cellSize);
	extraLives[1].setPosition(210 * cellSize, 7 * cellSize);

}
void IceCapZone::levelTriggers() {

	Player* modifyPlayer = sonic;
	if (sonic->get_isPlayerActive()) modifyPlayer = sonic;
	else if (tails->get_isPlayerActive()) modifyPlayer = tails;
	else if (knuckles->get_isPlayerActive()) modifyPlayer = knuckles;

	if (!modifyPlayer) return;

	//Breakable Bridge:
	if (modifyPlayer->get_playerX() >= 40 * cellSize && modifyPlayer->get_playerX() <= 42 * cellSize && !isOnBridge1) {
		bridgeClock1.restart();
		isOnBridge1 = true;
	}
	else if (modifyPlayer->get_playerX() >= 52 * cellSize && modifyPlayer->get_playerX() <= 54 * cellSize && !isOnBridge2) {
		bridgeClock2.restart();
		isOnBridge2 = true;
	}

	//Switch and Gate:
	if (((modifyPlayer->get_playerX() >= 120 * cellSize && modifyPlayer->get_playerX() <= 121 * cellSize) ||
		(modifyPlayer->get_playerX() >= 142 * cellSize && modifyPlayer->get_playerX() <= 143 * cellSize)) &&
		(modifyPlayer->get_playerY() >= (rows - 3) * cellSize + cellSize / 2 || modifyPlayer->get_playerY() <= (rows - 2) * cellSize - cellSize)) {
		switchClock.restart();
		isswitchOn = true;
		grid[8][139] = 0;
	}

	if (isOnBridge1 && bridgeClock1.getElapsedTime().asSeconds() > 0.5) { for (int j = 40; j < 48; j++) grid[12][j] = 0; bridgeFall.play(); }
	if (isOnBridge2 && bridgeClock2.getElapsedTime().asSeconds() > 0.5) {
		for (int j = 52; j < 60; j++) grid[12][j] = 0;  bridgeFall.play();
	}
	if (switchClock.getElapsedTime().asSeconds() > 3) { isswitchOn = false; grid[8][139] = 6; }

	if (modifyPlayer->get_playerX() >= 160 * cellSize && modifyPlayer->get_playerX() <= 180 * cellSize && !onbreakable)
	{
		breakablePath.restart();
		onbreakable = true;
	}

	if (onbreakable) {
		if (breakablePath.getElapsedTime().asMilliseconds() > 300 && breakablePath.getElapsedTime().asMilliseconds() < 500)
		{
			grid[8][160] = 0;
			grid[8][161] = 0;
		}
		if (breakablePath.getElapsedTime().asMilliseconds() > 700 && breakablePath.getElapsedTime().asMilliseconds() < 800)
		{
			grid[8][164] = 0;
			grid[8][165] = 0;
		}
		if (breakablePath.getElapsedTime().asMilliseconds() > 800 && breakablePath.getElapsedTime().asMilliseconds() < 1000) {
			grid[8][168] = 0;
			grid[8][170] = 0;
			grid[8][172] = 0;
		}

		if (breakablePath.getElapsedTime().asMilliseconds() > 1000 && breakablePath.getElapsedTime().asMilliseconds() < 1100) {
			grid[8][175] = 0;
			grid[8][177] = 0;
			grid[8][179] = 0;
		}
	}
}
void IceCapZone::deployEnemies() {
	beeBot[0]->setEnemy(28, 35, 6);
	beeBot[1]->setEnemy(93, 103, 6);
	beeBot[2]->setEnemy(240, 250, 6);

	motoBug[0]->setEnemy(11, 17, 10);
	motoBug[1]->setEnemy(60, 75, 9);
	motoBug[2]->setEnemy(192, 199, 5);
}