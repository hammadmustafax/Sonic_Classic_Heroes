#pragma once
#include "header.h"

class Collectibles {
protected:
	Animation* animation;
	bool* conditionsforAnimations;
	int numofAnimations;
	Sprite* activeSprite = nullptr;

	int collectibleHeight;
	int collectibleWidth;

	float collectibleX;
	float collectibleY;

	int currentX;

	int cellSize;
	bool isCollectibleActive;

	Music collectableMusic;

public:
	void setPosition(float x, float y) {
		collectibleX = x;
		collectibleY = y;
	}

	bool Collision(float playerX, float playerY) {
		bool collisionX = (playerX + cellSize >= collectibleX && collectibleX + cellSize >= playerX);
		bool collisionY = (playerY + cellSize >= collectibleY && collectibleY + cellSize >= playerY);

		if (collisionX && collisionY) {
			isCollectibleActive = false;
			collectableMusic.play();
		}
		return (isCollectibleActive) ? false : true;
	}

	void display(RenderWindow& window, float off) {
		if (isCollectibleActive) {
			activeSprite->setPosition(collectibleX - off, collectibleY);
			window.draw(*activeSprite);
		}
	}

	bool getisCollectibleActive() {
		return isCollectibleActive;
	}

	void nextFrame(float off) {
		if (!isCollectibleActive) return;
		conditionsforAnimations[0] = true;
		activeSprite = animation->animate(off, collectibleX, collectibleY);
	}

	void update(int vol) {
		collectableMusic.setVolume(vol);
	}
};