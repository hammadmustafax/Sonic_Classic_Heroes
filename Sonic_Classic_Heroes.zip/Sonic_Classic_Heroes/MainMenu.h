#pragma once
#include <iostream>
#include <string>
#include "Header.h"

class MainMenu {
private:
	bool startNewGame;
	bool startSavedGame;
	bool openScoreBoard;
	bool openOptions;
	bool exitGame;

	bool ismainMenuActive;
	bool isSavedStatePresent;

	int screen_x;
	int screen_y;

	Font* font1;
	Font* font2;

	Texture* backgroundTexture;
	Sprite* backgroundSprite;

	Text* nameOfGame;
	Text* menuHeading;
	Text* copyright;

	RectangleShape* layer;

	int menuOptions;
	int optionSelected;
	string *options;
	
	Text* menu;
	RectangleShape* box;

	Music menuMusic;

	void makeMenu();

public:
	MainMenu(int screen_x, int screen_y, int& volume);
	~MainMenu();

	void set_startNewGame(bool);
	void set_startSavedGame(bool);
	void set_openScoreBoard(bool);
	void set_openOptions(bool);
	void set_exitGame(bool);
	void set_ismainMenuActive(bool);
	void set_isSavedStatePresent(bool);

	bool get_startNewGame();
	bool get_startSavedGame();
	bool get_openScoreBoard();
	bool get_openOptions();
	bool get_exitGame();
	bool get_ismainMenuActive();
	bool get_isSavedStatePresent();

	bool checkForSavedGame();
	char* takeNameInput(RenderWindow&);

	void handleInput(RenderWindow&, Event&);
	void display(RenderWindow&);

	void playMusic();
	void stopMusic();
	void update(int);
};
