#pragma once
#include "Header.h"
#include "Animation.h"

class Player {
protected:
	Animation* animation;
	bool* conditionsforAnimations;
	int numofAnimations;
	Sprite* activeSprite = nullptr;

	int cellsize = 64;
	int hp;
	float speed;

	bool isPlayerActive;

	float playerX;
	float playerY;

	bool isHit;
	float invincibilityTime = 1;
	Clock invincibilityTimer;

	bool isPowerUpActive;
	Clock powerUpClock;

	Music jumpMusic;
	bool spaceAlreadyPressed;
	int maxFlyTime = 7;

	int levelWidth;
	bool* levelStart;

	Clock collisionTimer;
	Music playerDamage;

	//------------- Elements for Collision Detection -----------------//
	float offset_y = 0, velocityY = 0, terminal_Velocity = 20;
	bool onGround = true; int hit_box_factor_x = 2.5, hit_box_factor_y = 2.5;
	bool leftcollision = false;
	bool rightcollision = false;
	bool topcollision = false;
	bool bottomcollision = false;

	//--------------- Elements for jumping ---------------//
	bool isPlayerJumping = false;
	Clock jumpTimer;
	float jump_offset = -25;

	bool isPlayerFacingRight = true;
	bool isPlayerMoving = false;

	Clock specialAbilityClock;
	bool isSpecialAbilityActive = false;

public:
	Player(bool isPlayerActive) {

		playerX = 10;
		playerY = 8 * 64;

		this->isPlayerActive = isPlayerActive;
		isPowerUpActive = false;

		isHit = false;
		hp = 3; 

		jumpMusic.openFromFile("Music/Jump.wav");
		playerDamage.openFromFile("Music/Damage.mp3");
	}

	Player(bool isPlayerActive, float playerX, float playerY, int hp, bool isPlayerJumping,
		bool isSpecialAbilityActive, bool isPlayerMoving, bool isPlayerFacingRight,
		int levelWidth, bool canbeHit, int currentAnimation, bool velocityY,
		bool onGround, bool leftcollision, bool rightcollision, bool topcollision,
		bool bottomcollision) {

		this->isPlayerActive = isPlayerActive;
		this->playerX = playerX;
		this->playerY = playerY;
		this->hp = hp;

		this->isPlayerJumping = isPlayerJumping;
		this->isSpecialAbilityActive = isSpecialAbilityActive;

		this->isPlayerMoving = isPlayerMoving;
		this->isPlayerFacingRight = isPlayerFacingRight;

		this->levelWidth = levelWidth;

		this->isHit = canbeHit;

		//this->currentAnimation = currentAnimation;

		this->velocityY = velocityY;
		this->onGround = onGround;

		this->leftcollision = leftcollision;
		this->rightcollision = rightcollision;
		this->topcollision = topcollision;
		this->bottomcollision = bottomcollision;
	}

	//Getters:
	int getNumberOfAnimations() {
		return numofAnimations;
	}
	int getPlayerHP() {
		return hp;
	}
	float getPlayerSpeed() {
		return speed;
	}
	bool getIsPlayerActive() {
		return isPlayerActive;
	}
	float getPlayerX() {
		return playerX;
	}
	float getPlayerY() {
		return playerY;
	}
	bool getIsHit() {
		return isHit;
	}
	float getInvincibilityTimer() {
		return invincibilityTimer.getElapsedTime().asSeconds();
	}
	bool getIsPowerUpActive() {
		return isPowerUpActive;
	}
	float getPowerUpClock() {
		return powerUpClock.getElapsedTime().asSeconds();
	}
	bool getSpaceAlreadyPressed() {
		return spaceAlreadyPressed;
	}
	int getMaxFlyTime() {
		return maxFlyTime;
	}
	int getLevelWidth() {
		return levelWidth;
	}
	bool getLevelStart() {
		if (levelStart) return *levelStart;
		else return false;
	}
	float getOffsetY() {
		return offset_y;
	}
	float getVelocityY() {
		return velocityY;
	}
	bool getOnGround() {
		return onGround;
	}
	bool getLeftcollision() {
		return leftcollision;
	}
	bool getRightcollision() {
		return rightcollision;
	}
	bool getTopcollision() {
		return rightcollision;
	}
	bool getBottomcollision() {
		return bottomcollision;
	}
	bool getIsPlayerJumping() {
		return isPlayerJumping;
	}
	float getJumpTimer() {
		return jumpTimer.getElapsedTime().asSeconds();
	}
	bool getIsFacingRight() {
		return isPlayerFacingRight;
	}
	bool getIsMoving() {
		return isPlayerMoving;
	}
	bool getIsAbilityActive() {
		return isSpecialAbilityActive;
	}
	float getSpecialAbilityTime() {
		return specialAbilityClock.getElapsedTime().asSeconds();
	}

	void SetPosition(float x, float y) {
		playerX = x;
		playerY = y;
	}
	void display(RenderWindow& window, float xCord) {
		if (!activeSprite) return;
		activeSprite->setPosition(xCord, playerY);
		if (isHit)
			activeSprite->setColor(sf::Color(128, 128, 128, 255));
		else
			activeSprite->setColor(sf::Color(255, 255, 255, 255));
		window.draw(*activeSprite);
	}

	void setIsPowerUpActive(bool isPowerUpActive) {
		this->isPowerUpActive = isPowerUpActive;
	}

	void setInvincibilityTimer() {
		invincibilityTimer.restart();
	}
	
	float getHitTimer() {
		return invincibilityTimer.getElapsedTime().asSeconds();
	}

	bool getIsPlayerFacingRight() {
		return isPlayerFacingRight;
	}

	void setVelocityY(float velocityY) {
		this->velocityY = velocityY;
	}

	void setOnGround(bool onGround) {
		this->onGround = onGround;
	}

	void setPowerUpClock() {
		powerUpClock.restart();
	}

	void setPlayerHP(int hp) {
		this->hp = hp;
	}

	void setIsLevelStart(bool* levelStart) {
		this->levelStart = levelStart;
	}

	void setInvincibilityTime(float invincibilityTime) {
		this->invincibilityTime = invincibilityTime;
	}

	void setSpeed(float speed) {
		this->speed = speed;
	}

	float get_playerX() {
		return playerX;
	}

	void set_playerX(float x) {
		playerX = x;
	}

	float get_playerY() {
		return playerY;
	}

	void set_playerY(float y) {
		playerY = y;
	}

	bool get_isPlayerActive() {
		return isPlayerActive;
	}

	void set_isPlayerActive(bool isPlayerActive) {
		this->isPlayerActive = isPlayerActive;
	}

	float get_speed() {
		return speed;
	}

	void setSpaceAlreadyPressed(bool spaceAlreadyPressed) {
		this->spaceAlreadyPressed = spaceAlreadyPressed;
	}
	
	void setMaxFlyTime(int maxFlyTime) {
		this->maxFlyTime = maxFlyTime;
	}

	void setIsPlayerJumping(bool isPlayerJumping) {
		this->isPlayerJumping = isPlayerJumping;
	}

	float getInvincibilityTime() {
		return invincibilityTime;
	}

	Sprite* getSprite(){
		return activeSprite;
	}

	void setIsHit(bool hit) {
		isHit = hit;
	}
	float getCollisionClock() {
		return collisionTimer.getElapsedTime().asSeconds();
	}
	void resetCollisionClock() {
		collisionTimer.restart();
	}

	void playerDamageMusic() {
		playerDamage.play();
	}

	void HandleEvent(RenderWindow& window, Event& event, float time) {
		if (event.type == Event::Closed) window.close();
	}

	void jump(float time, int** grid , float gravity) {

		if (isPlayerJumping) {
			jumpTimer.restart();
			velocityY += gravity;
			if (velocityY > terminal_Velocity) velocityY = terminal_Velocity;

			float tempY = playerY + velocityY * time / 30;
			int x_axis = (int)(tempY - 1) / cellsize;
			int y_axis = (int)(playerX + cellsize / 2) / cellsize;

			int tcollision = -1;
			if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth) {
				tcollision = grid[x_axis][y_axis];
			}

			if (((tcollision != 1 && tcollision != 3) || (tcollision == -1)) && tempY >= 0) playerY = tempY;
		}
	}

	virtual void handleUpdate(float time, int** grid, float friction, int volume, float offset , float gravity) {
		
		if (collisionTimer.getElapsedTime().asSeconds() > 1) {
			isHit = false;
		}

		jumpMusic.setVolume(volume);
		playerDamage.setVolume(volume);
		
		update(time, grid, friction, volume, gravity);
		jump(time, grid , gravity);
		player_gravity(grid , gravity);
		animate(offset);
	}

	virtual void update(float time, int** grid, float friction, int volume ,float gravity) = 0;

	void animate(float off) {
		for (int i = 0; i < numofAnimations; i++) conditionsforAnimations[i] = false;

		if (!isPlayerMoving && !isPlayerJumping) {
			if (!isPlayerFacingRight) conditionsforAnimations[0] = true;
			else conditionsforAnimations[1] = true;
		}
		else if (isSpecialAbilityActive) {
			if (!isPlayerFacingRight) conditionsforAnimations[6] = true;
			else conditionsforAnimations[7] = true;
		}
		else if (isPlayerJumping) {
			if (!isPlayerFacingRight) conditionsforAnimations[4] = true;
			else conditionsforAnimations[5] = true;
		}
		else if (isPlayerMoving) {
			if (!isPlayerFacingRight) conditionsforAnimations[2] = true;
			else conditionsforAnimations[3] = true;
		}
		activeSprite = animation->animate(off, playerX, playerY);
	}

	void player_gravity(int** grid , float gravity) {
		if (grid == nullptr) return;

		int x_axis = (int)(playerY + hit_box_factor_y + cellsize) / cellsize;
		int y_axis = (int)(playerX + hit_box_factor_x) / cellsize;
		int bottom_collision_left = -1;
		if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth)
			bottom_collision_left = grid[x_axis][y_axis];

		x_axis = (int)(playerY + hit_box_factor_y + cellsize) / cellsize;
		y_axis = (int)(playerX + hit_box_factor_x + cellsize / 2) / cellsize;
		int bottom_collision_right = -1;
		if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth)
			bottom_collision_right = grid[x_axis][y_axis];


		x_axis = (int)(playerY + hit_box_factor_y + cellsize) / cellsize;
		y_axis = (int)(playerX + hit_box_factor_x + cellsize / 4) / cellsize;
		int bottom_collision_mid = -1;
		if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth)
			bottom_collision_mid = grid[x_axis][y_axis];

		offset_y = playerY + velocityY;

		if ((bottom_collision_left != -1 && bottom_collision_left != 0) ||
			(bottom_collision_right != -1 && bottom_collision_right != 0) ||
			(bottom_collision_mid != -1 && bottom_collision_mid != 0)) bottomcollision = true;
		else bottomcollision = false;

		if (bottomcollision) {
			onGround = true;
			isPlayerJumping = false;
			velocityY = 0;
			playerY = ((int)((playerY + cellsize) / cellsize) * cellsize) - (cellsize);
		}
		else {
			onGround = false;
			playerY = offset_y;
		}

		if (!onGround) {
			velocityY += gravity;
			if (velocityY >= terminal_Velocity) velocityY = terminal_Velocity;
		}
		else {
			velocityY = 0;
		}

		// left and Right Collision
		// Player cellsize/2 inoder to ensure overlapping of rectangular hitboxes of the sprites and the player.
		
		x_axis = (int)((playerY + cellsize / 2) / cellsize);
		y_axis = (int)((playerX - 1) / cellsize);
		int lcollision = -1;
		if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth)
			lcollision = grid[x_axis][y_axis];
		
		x_axis = (int)((playerY + cellsize / 2) / cellsize);
		y_axis = (int)((playerX + cellsize + 1) / cellsize);
		int rcollision = -1;
		if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth)
			rcollision = grid[x_axis][y_axis];

		x_axis = (int)(playerY - 1) / cellsize;
		y_axis = (int)(playerX + cellsize / 2) / cellsize;
		int tcollision = -1;
		if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < levelWidth)
			tcollision = grid[x_axis][y_axis];

		if (lcollision == 1 || lcollision == 3 || lcollision == 6) leftcollision = true;
		else leftcollision = false;

		if (rcollision == 1 || rcollision == 3 || rcollision == 6) rightcollision = true;
		else rightcollision = false;

		if (tcollision == 1 || tcollision == 3) { velocityY = 0; topcollision = true; if (!bottomcollision) playerY += 2; }
		else topcollision = false;
	}

	void setLevelWidth(int levelWidth) {
		this->levelWidth = levelWidth;
	}

	void MoveRight(float time, float friction) {
		if (playerX < ((levelWidth - 1) * cellsize) && rightcollision == false) playerX += speed * time / 30 * friction;
		if (levelStart && *levelStart == false) *levelStart = true;

		isPlayerMoving = true;
		isPlayerFacingRight = true;
	}

	void MoveLeft(float time, float friction) {
		if (playerX > 0 && leftcollision == false) playerX -= speed * time / 30 * friction;
		if (levelStart && *levelStart == false) *levelStart = true;

		isPlayerMoving = true;
		isPlayerFacingRight = false;
	}
};