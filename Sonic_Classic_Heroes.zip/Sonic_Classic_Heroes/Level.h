#pragma once
#include "Player.h"
#include "Enemy.h"
#include "Rings.h"
#include "CrabMeat.h"
#include "EggStinger.h"
#include "MotoBug.h"
#include "BeeBot.h"
#include "BatBrain.h"
#include "Header.h"

class Level {
protected:

	Collectibles* rings;
	Collectibles* specialBoost;
	Collectibles* extraLives;
	
	Enemy** crabMeat;
	Enemy** beeBot;
	Enemy** batBrain;
	Enemy** motoBug;
	Enemy** eggStinger;

	Player* sonic;
	Player* tails;
	Player* knuckles;

	int numOfBeeBot;
	int numOfMotoBug;
	int numOfCrabMeat;
	int numOfBatBrain;

	int numofRings;
	int numofSpecialBoosts;
	int numofExtraLives;

	int ringsLeft;

	int offset;

	int rows;
	int cols;
	int cellSize;
	int** grid;

	bool isLevelEnd;
	bool isLevelWon;
	bool isLevelLost;

	int currentLevel;
	
	float friction;
	float gravity;

	// Music Setting 
	Music LevelMusic;
	Music bridgeFall;

	Texture backgroundTexture;
	Sprite backgroundSprite;

	Texture brick1Texture;
	Texture brick2Texture;
	Texture brick3Texture;

	Texture bridgeTexture;
	Texture switchTexture;
	Texture gateTexture;
	Texture spikeTexture;
	
	Sprite brick1Sprite;
	Sprite brick2Sprite;
	Sprite brick3Sprite;

	Sprite bridgeSprite;
	Sprite switchSprite;
	Sprite gateSprite;
	Sprite spikeSprite;

	bool isswitchOn;
	bool isOnBridge1;
	bool isOnBridge2;

	Clock switchClock;
	Clock bridgeClock1;
	Clock bridgeClock2;

	int levelTime;
	Clock levelTimeClock;
	bool levelStart;

	// -------------------------------------- Player Following ---------------------------//
	int size = 50;
	float* posX = new float[size];
	float* posY = new float[size];
	int currentIndex;
	float delayInFollowing;
	int totalData = 0;
	float delayBetweenUpdate = 0;

public:
	Level(int, Player*, Player* = nullptr, Player* = nullptr);
	~Level();

	void setLevelEnd(bool);
	void setLevelWon(bool);
	void setLevelLost(bool);

	bool getLevelEnd();
	bool getLevelWon();
	bool getLevelLost();

	void setCurrentLevel(int);
	int getCurrentLevel();

	void update(float, int&, int);

	virtual void levelTriggers() = 0;

	void handleInput(RenderWindow&, Event&, float time);
	void display(RenderWindow&, int&);

	int** get_grid() {
		return grid;
	}
	int get_rows() {
		return rows;
	}
	int get_column() {
		return cols;
	}

	void playMusic();

	void positionTrack(float playerX, float playerY);
	bool trailing(int trailingIdx, float& outX, float& outY);
	void autoPlay(float time);
};