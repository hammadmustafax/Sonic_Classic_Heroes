#include <fstream>
#include "LeaderBoard.h"
#include "Header.h"

LeaderBoard::LeaderBoard(int screen_x, int screen_y) {

	this->screen_x = screen_x; this->screen_y = screen_y;

	backtoMenu = false;
	backgroundTexture = new Texture;
	backgroundSprite = new Sprite;

	backgroundTexture->loadFromFile("MainMenuSprites/bg.jpg");
	backgroundSprite->setTexture(*backgroundTexture);
}

LeaderBoard::~LeaderBoard() {
	delete backgroundTexture; backgroundTexture = nullptr;
	delete backgroundSprite; backgroundSprite = nullptr;
}

void LeaderBoard::set_backtoMenu(bool backtoMenu) {
	this->backtoMenu = backtoMenu;
}

bool LeaderBoard::get_backtoMenu() {
	return backtoMenu;
}

void LeaderBoard::handleInput(RenderWindow& window, Event& event) {

	if (event.type == Event::Closed) window.close();
	else if (event.type == Event::KeyPressed) {
		if (event.key.code == Keyboard::Escape) {
			backtoMenu = true;
		}
	}
}

void LeaderBoard::compareScores(int playerScore, string playerName) {

	fstream scoreFile;
	const int size = 11;

	string name[size] = {};
	int highscores[size] = {};

	scoreFile.open("highscores.txt", ios::in);

	for (int i = 1; i < size; i++)
		scoreFile >> name[i] >> highscores[i];

	scoreFile.close();

	highscores[0] = playerScore;
	name[0] = playerName;

	for (int i = 0; i < size - 1; i++) {

		bool swapStatus = false;

		for (int j = 0; j < size - i - 1; j++) {

			if (highscores[j] < highscores[j + 1]) {

				int temp1 = highscores[j];
				highscores[j] = highscores[j + 1];
				highscores[j + 1] = temp1;

				string temp2 = name[j];
				name[j] = name[j + 1];
				name[j + 1] = temp2;

				swapStatus = true;
			}
		}

		if (!swapStatus) break;
	}

	scoreFile.open("highscores.txt", ios::out);

	for (int i = 0; i < size - 1; i++) {

		if (name[i] != "\0") {
			scoreFile << name[i];
			scoreFile << " ";
			scoreFile << highscores[i] << endl;
		}
	}

	scoreFile.close();
}

void LeaderBoard::display(RenderWindow& window) {

	Font font1; font1.loadFromFile("Fonts/ARCADE_I.TTF");
	Font font2;	font2.loadFromFile("Fonts/arial.ttf");

	fstream scoreFile;
	string names[10] = {};
	int highscores[10] = {};

	scoreFile.open("highscores.txt", ios::in);

	for (int i = 0; i < 10; i++) {
		scoreFile >> names[i];
		scoreFile >> highscores[i];
	}

	scoreFile.close();

	Texture backgroundTexture;
	Sprite backgroundSprite;
	backgroundTexture.loadFromFile("MainMenuSprites/bg.jpg");
	backgroundSprite.setTexture(backgroundTexture);

	Text nameOfGame;
	nameOfGame.setFont(font1);
	nameOfGame.setString("Sonic Classic Heroes");
	nameOfGame.setCharacterSize(50);
	nameOfGame.setPosition(screen_x / 2 - 490, 70);
	nameOfGame.setFillColor(Color::Yellow);

	Text heading;
	heading.setFont(font1);
	heading.setString("High Scores");
	heading.setCharacterSize(40);
	heading.setPosition(screen_x / 2 - 220, 180);
	heading.setFillColor(Color(173, 216, 230));

	/*Music menuMusic;
	menuMusic.openFromFile("Music/Title.ogg");
	menuMusic.play();
	menuMusic.setVolume(50);*/

	Text  name[10];
	Text score[10];

	for (int i = 0; i < 10; i++) {

		if (names[i] == "\0")
			continue;

		name[i].setPosition(screen_x / 2 - 200, 300 + 50 * i);
		name[i].setFont(font2);
		name[i].setCharacterSize(25);
		name[i].setFillColor(Color(152, 255, 152));
		name[i].setString(names[i]);

		score[i].setPosition(screen_x / 2 + 170, 300 + 50 * i);
		score[i].setFont(font2);
		score[i].setCharacterSize(25);
		score[i].setFillColor(Color(255, 182, 193));
		score[i].setString(to_string(highscores[i]));
	}

	Text copyright;
	copyright.setFont(font2);
	copyright.setString("A production of Muhammad Mughees Tariq Khawaja & Muhammad Hammad Mustafa");
	copyright.setCharacterSize(20);
	copyright.setPosition(screen_x / 2 - 380, screen_y - 30);
	copyright.setFillColor(Color::White);

	RectangleShape layer(Vector2f(screen_x, screen_y));
	layer.setFillColor(Color(0, 0, 0, 150));

	Text exit;
	exit.setFont(font2);
	exit.setString("(Press escape button to exit to main menu)");
	exit.setCharacterSize(25);
	exit.setPosition(screen_x / 2 - 240, 250);
	exit.setFillColor(Color::White);

	window.clear();
	window.draw(backgroundSprite);
	window.draw(layer);
	window.draw(nameOfGame);
	window.draw(heading);
	window.draw(copyright);
	window.draw(exit);

	for (int i = 0; i < 10; i++) {
		window.draw(name[i]);
		window.draw(score[i]);
	}
}
