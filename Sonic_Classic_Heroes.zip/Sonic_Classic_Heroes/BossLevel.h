#pragma once
#include "Level.h"
#include "Player.h"
#include "Header.h"

class BossLevel : public Level {
private:
	int levelNumber;
	void makeMap();
	void levelTriggers();
public:
	BossLevel(int, Player*);
	~BossLevel();
};