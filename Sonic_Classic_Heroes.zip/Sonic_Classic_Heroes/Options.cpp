#include "Options.h"
#include "Header.h"

Options::Options() {
	
	backtoMenu = false;
	backgroundTexture = new Texture;
	backgroundSprite = new Sprite;

	backgroundTexture->loadFromFile("MainMenuSprites/bg.jpg");
	backgroundSprite->setTexture(*backgroundTexture);
}

Options::~Options() {
	delete backgroundTexture; backgroundTexture = nullptr;
	delete backgroundSprite; backgroundSprite = nullptr;
}

void Options::display(RenderWindow& window, int& volume) {
	window.draw(*backgroundSprite);
	volumeText(window, volume);
}

void Options::volumeText(RenderWindow& window, int& volume) {
	
	Font font1, font2;
	Text nameOfGame, heading, copyright;

	font1.loadFromFile("Fonts/ARCADE_I.TTF");
	font2.loadFromFile("Fonts/arial.ttf");

	nameOfGame.setFont(font1);
	nameOfGame.setString("Sonic Classic Heroes");
	nameOfGame.setCharacterSize(50);
	nameOfGame.setPosition(1280 / 2 - 490, 70);
	nameOfGame.setFillColor(Color::Yellow);

	heading.setFont(font1);
	heading.setString("Options");
	heading.setCharacterSize(40);
	heading.setPosition(1280 / 2 - 155, 180);
	heading.setFillColor(Color(173, 216, 230));

	copyright.setFont(font2);
	copyright.setString("A production of Muhammad Mughees Tariq Khawaja & Muhammad Hammad Mustafa");
	copyright.setCharacterSize(20);
	copyright.setPosition(1280 / 2 - 380, 896 - 30);
	copyright.setFillColor(Color::White);
	
	RectangleShape layer(Vector2f(1280, 896));
	layer.setFillColor(Color(0, 0, 0, 150));
	Font font; font.loadFromFile("Fonts/arial.ttf");
	Text volumeText;
	volumeText.setFont(font);
	volumeText.setString("Volume Level: " + to_string(volume));
	volumeText.setFillColor(Color::Black);
	volumeText.setCharacterSize(40);
	volumeText.setPosition(450, 440);
	
	Text exit;
	exit.setFont(font2);
	exit.setString("(Press escape button to exit to main menu)");
	exit.setCharacterSize(25);
	exit.setPosition(1280 / 2 - 260, 260);
	exit.setFillColor(Color::White);

	Text instruct;
	instruct.setFont(font2);
	instruct.setString("(Press up button to increase or down button to decrease Volume)");
	instruct.setCharacterSize(25);
	instruct.setPosition(1280 / 2 - 380, 350);
	instruct.setFillColor(Color::White);

	RectangleShape box;
	box.setSize(Vector2f(370, 70));
	box.setFillColor(Color::Transparent);
	box.setOutlineColor(Color::White);
	box.setOutlineThickness(2);
	box.setPosition(420, 430);

	window.draw(volumeText);
	window.draw(layer);
	window.draw(heading);
	window.draw(nameOfGame);
	window.draw(copyright);
	window.draw(exit);
	window.draw(instruct);
	window.draw(box);
}

void Options::set_backtoMenu(bool backtoMenu) {
	this->backtoMenu = backtoMenu;
}

bool Options::get_backtoMenu() {
	return backtoMenu;
}

void Options::handleInput(RenderWindow& window, Event& event, int& volume) {
	
	if (event.type == Event::Closed) window.close();
	else if (event.type == Event::KeyPressed) {
		if (event.key.code == Keyboard::Escape) {
			backtoMenu = true;
		}
	}
	else if (event.key.code == Keyboard::Up) {
		if (volume < 100) volume +=5;
	}
	else if (event.key.code == Keyboard::Down) {
		if (volume > 0) volume -=5;
	}
}
