#pragma once
#include "Level.h"
#include "Player.h"
#include "Header.h"

class DeathEggZone : public Level {
private:
	int levelNumber;
	void makeMap();
	void deployCollectibles();
	void deployEnemies();
	void levelTriggers();
	Clock breakablePath;
	bool onbreakable;

public:
	DeathEggZone(int, Player*, Player*, Player*);
	~DeathEggZone();
};