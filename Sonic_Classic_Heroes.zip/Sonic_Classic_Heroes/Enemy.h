#pragma once
#include "header.h"

class Enemy {
protected:
	Animation* animation;
	bool* conditionsforAnimations;
	int numofAnimations;
	Sprite* activeSprite = nullptr;

	int currentX;
	int enemyHeight;
	int enemyWidth;

	float enemyX;
	float enemyY;
	float enemySpeed;

	int cellSize;
	bool isEnemyActive;
	bool isEnemyAttacking;

	int regionLeft;
	int regionRight;

	bool isFacingRight;
	Clock movementClock;
	Clock attackClock;
	Clock collisionClock;

	Music EnemyKill;

	bool bulletCollision;
	int hp;

public:
	Enemy() {
		isEnemyActive = false;
		isEnemyAttacking = false;
		isFacingRight = true;

		enemyX = 0;
		enemyY = 0;

		enemyWidth = 64;
		enemyHeight = 64;
		cellSize = 64;

		regionLeft = 0;
		regionRight = 0;

		movementClock.restart();
		attackClock.restart();

		EnemyKill.openFromFile("Music/Enemykill.mp3");
	}

	float getEnemyX() {
		return enemyX;
	}
	float getEnemyY() {
		return enemyY;
	}
	bool getIsEnemyActive() {
		return isEnemyActive;
	}
	void setIsEnemyActive(bool isEnemyActive) {
		this->isEnemyActive = isEnemyActive;
	}
	int getEnemyHP() {
		return hp;
	}
	void setEnemyHP(int hp) {
		this->hp = hp;
	}
	void enemyKillMusic(bool play) {
		if (play) EnemyKill.play();
		else EnemyKill.stop();
	}
	bool getBulletCollision() {
		return bulletCollision;
	}

	virtual void animate(float off) = 0;
	virtual void update(float time ,  float playerX = 0, float playerY = 0 , int** grid = nullptr, int vol = 0) = 0;
	virtual void display(RenderWindow& window, float off) = 0;
	virtual void movement(float time) = 0;
	virtual void attack(float time, float playerX, float playerY) = 0;

	virtual bool collision1D(float body1_cord, int body1_size, float body2_cord, int body2_size) {
		if (body1_cord + body1_size >= body2_cord && body2_cord + body2_size >= body1_cord) return true;
		return false;
	}

	virtual bool collision2D(float playerX, float playerY, bool isRollingState, int& score) {

		bool collisionX = (playerX + cellSize >= enemyX && enemyX + cellSize >= playerX);
		bool collisionY = (playerY + cellSize >= enemyY && enemyY + cellSize >= playerY);

		if (collisionX && collisionY) {
			return true;
		}
		return false;
	}

	virtual void setEnemy(float regionLeft, float regionRight, float y) {
		this->regionLeft = regionLeft; this->regionRight = regionRight;
		enemyX = (regionRight - (regionRight - regionLeft) / 2) * cellSize; enemyY = y * cellSize;
		isEnemyActive = true;
	}
};