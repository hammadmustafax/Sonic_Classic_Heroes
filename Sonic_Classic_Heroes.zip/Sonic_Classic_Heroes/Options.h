#pragma once
#include "Header.h"

class Options {
private:
	bool backtoMenu;
	Sprite* backgroundSprite;
	Texture* backgroundTexture;

public:
	Options();
	~Options();

	void volumeText(RenderWindow&, int&);

	void set_backtoMenu(bool);
	bool get_backtoMenu();

	void display(RenderWindow&, int&);
	void handleInput(RenderWindow&, Event&, int&);
};