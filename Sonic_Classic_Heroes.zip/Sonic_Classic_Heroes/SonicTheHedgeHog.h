#pragma once
#include "Header.h"
#include "Player.h"

class SonicTheHedgeHog : public Player {
public:
	SonicTheHedgeHog(bool isPlayerActive) : Player(isPlayerActive) {

		numofAnimations = 8;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/SonicIdleLeft.png"; paths[1] = "Data/SonicIdleRight.png";
		paths[2] = "Data/SonicWalkLeft.png"; paths[3] = "Data/SonicWalkRight.png";
		paths[4] = "Data/SonicJumpLeft.png"; paths[5] = "Data/SonicJumpRight.png";
		paths[6] = "Data/SonicRunLeft.png"; paths[7] = "Data/SonicRunRight.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 64; totalWidth[1] = 64; totalWidth[2] = 640; totalWidth[3] = 640;
		totalWidth[4] = 512; totalWidth[5] = 512; totalWidth[6] = 512; totalWidth[7] = 512;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool*[numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];
		
		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);
		speed = 18;
	}

	void update(float time, int** grid, float friction, int volume , float gravity) {

		isPlayerMoving = false;

		if (Keyboard::isKeyPressed(Keyboard::Right)) MoveRight(time, friction);
		if (Keyboard::isKeyPressed(Keyboard::Left)) MoveLeft(time, friction);
		if (Keyboard::isKeyPressed(Keyboard::Space)) {
			if (!isPlayerJumping && onGround && jumpTimer.getElapsedTime().asSeconds() > 0.1) { jumpTimer.restart(); onGround = false; isPlayerJumping = true; velocityY = jump_offset; jumpMusic.play(); }
		}

		specialAbility(time, grid);
	}

	void specialAbility(float time, int** grid) {
		
		if ((!isPlayerMoving) ||
			(isPlayerFacingRight && animation->getCurrentAnimation() % 2 == 0) ||
			(!isPlayerFacingRight && animation->getCurrentAnimation() % 2 != 0)) {

			specialAbilityClock.restart();
			
			if (isSpecialAbilityActive) speed -= 4;
			isSpecialAbilityActive = false;
		}

		if (specialAbilityClock.getElapsedTime().asSeconds() > 1) {
			if (!isSpecialAbilityActive) speed += 4;
			isSpecialAbilityActive = true;
		}
			
		if (isSpecialAbilityActive && isPlayerMoving) {
			
			if (isPlayerFacingRight) {
				if (playerX < (levelWidth - 1) * cellsize && rightcollision == false) playerX += speed * time / 30;
			}
			else {
				if (playerX > 0 && leftcollision == false) playerX -= speed * time / 30;
			}
		}
	}
};