#pragma once
#include "Level.h"
#include "Player.h"
#include "Header.h"

class IceCapZone : public Level {
private:
	int levelNumber;
	void makeMap();
	void levelTriggers();
	void deployCollectibles();
	void deployEnemies();
	Clock breakablePath;
	bool onbreakable;

public:
	IceCapZone(int,Player*, Player*, Player*);
	~IceCapZone();
};