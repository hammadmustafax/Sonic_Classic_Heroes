#include "LabyrinthZone.h"
#include "Rings.h"
#include "SpecialBoost.h"
#include "ExtraLives.h"
#include "CrabMeat.h"
#include "BatBrain.h"
#include "Header.h"

LabyrinthZone::LabyrinthZone(int levelNumber, Player* sonic, Player* tails, Player* knuckles) : Level(levelNumber, sonic, tails, knuckles) {

	friction = 0.8;
	levelTime = 100;
	gravity = 1;

	numOfCrabMeat = 3;
	crabMeat = new Enemy*[numOfCrabMeat]; for (int i = 0; i < numOfCrabMeat; i++) crabMeat[i] = new CrabMeat;

	numOfBatBrain = 3;
	batBrain = new Enemy*[numOfBatBrain]; for (int i = 0; i < numOfBatBrain; i++) batBrain[i] = new BatBrain;

	numofExtraLives = 2;
	extraLives = new ExtraLives[numofExtraLives];

	numofRings = 30;
	ringsLeft = numofRings;
	rings = new Rings[numofRings];

	numofSpecialBoosts = 2;
	specialBoost = new SpecialBoost[numofSpecialBoosts];

	this->levelNumber = levelNumber;
	cols = 200;
	grid = new int* [rows]; for (int i = 0; i < rows; i++) grid[i] = new int[cols];

	backgroundTexture.loadFromFile("Data/background1.jpg");
	backgroundSprite.setTexture(backgroundTexture);

	brick1Texture.loadFromFile("Data/brick11.png"); brick1Sprite.setTexture(brick1Texture);
	brick2Texture.loadFromFile("Data/brick12.png"); brick2Sprite.setTexture(brick2Texture);
	brick3Texture.loadFromFile("Data/brick13.png"); brick3Sprite.setTexture(brick3Texture);

	bridgeTexture.loadFromFile("Data/bridge1.png"); bridgeSprite.setTexture(bridgeTexture);
	switchTexture.loadFromFile("Data/switch1.png"); switchSprite.setTexture(switchTexture);

	LevelMusic.openFromFile("Music/level1.mp3");
	LevelMusic.setLoop(true);

	makeMap();
	deployCollectibles();
	deployEnemies();
}

LabyrinthZone::~LabyrinthZone() {
	for (int i = 0; i < rows; i++) delete[]grid[i];
	delete[]grid; grid = nullptr;
}

void LabyrinthZone::makeMap() {

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			grid[i][j] = 0;
		}
	}

	//Labyrinth Zone has 200 columns and if we make a section of 20 columns then only 10 sections are required

	//Block 1 is for ground
	//Block 2 is for breakable wall
	//Block 3 is for platforms not on ground
	//Block 4 is for bridge
	//Block 5 is for switch
	//Block 6 is for gate
	//Block 7 is for occupying space
	//Block 8 is for spikes


	//Section 1: 0-20 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < 20; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i < 2) { if (j > 7) grid[i][j] = 1; }
			else if (i < 4) { if (j > 5) grid[i][j] = 1; }
			else if (i < 6) { if (j > 9) grid[i][j] = 1; }
			else if (i == 9) { if (j < 2) grid[i][j] = 1; }
			else if (i == 10) { if (j < 5) grid[i][j] = 1; }
			else if (i > 10) grid[i][j] = 1;
		}
	}

	//Section 02: 20-40 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 20; j < 40; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i == 1) { if (j < 40) grid[i][j] = 1; }
			else if (i == 2) { if (j < 35) grid[i][j] = 1; }
			else if (i == 3) { if (j < 35) grid[i][j] = 1; }
			else if (i == 4 || i == 5) { if (j >= 29 && j <= 34) grid[i][j] = 1; }
			else if (i == 11) { if (j < 30 || j == 39) grid[i][j] = 1; }
			else if (i > 11) grid[i][j] = 1;
		}
	}

	//Section 03: 40-60 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 40; j < 60; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i < 3) { if (j < 43) grid[i][j] = 1; }
			else if (i < 7) { if (j >= 48 && j <= 51) grid[i][j] = 1; }
			else if (i == 12) { if (j >= 48 && j < 52) grid[i][j] = 1; else grid[i][j] = 4; }
		}
	}

	//Section 04: 60-80 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 60; j < 80; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (i < 1) { if (j > 67) grid[i][j] = 1; }
			else if (i < 2) { if (j > 65) grid[i][j] = 1; }
			else if (i < 3) { if (j > 69) grid[i][j] = 1; }
			else if (i == 7) { if ((j > 68 && j < 72) || (j > 74 && j < 78)) grid[i][j] = 2; }
			else if (i == 9) { if (j < 62) grid[i][j] = 1; }
			else if (i == 10) { if (j < 65) grid[i][j] = 1; }
			else if (i > 10) grid[i][j] = 1;
		}
	}
	grid[10][72] = 8;
	grid[10][73] = 8;
	grid[10][74] = 8;

	//Section 05: 80-100 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 80; j < 100; j++) {

			if (i == 0) grid[i][j] = 1;
			else if (j >= 87 && j <= 91) {
				if (i == 8) grid[i][j] = 3;	//I have assigned this 3 here for testing
				else grid[i][j] = 1;
			}
			else if (i >= 9) {
				grid[i][j] = 1;
			}
		}
	}

	//Section 06: 100-120 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 100; j < 120; j++) {
			if (i == 0) grid[i][j] = 1;
			else if ((i == 9 || i == 10) && ((j >= 100 && j <= 102) || (j >= 117 && j <= 119))) grid[i][j] = 1;
			//else if (i == 9 || i == 10) grid[i][j] = 2; //I have to make this 0 or remove this
		}
	}

	//Section 07: 120-140 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 120; j < 140; j++) {
			if (i == 0) grid[i][j] = 1;
			else if (i == 9) { if (j == 120) grid[i][j] = 5; else if (j == 121) grid[i][j] = 7; else grid[i][j] = 1; }
			else if (i == 8) continue;
			else grid[i][j] = 1;
		}
	}
	grid[8][139] = 6; //gate

	//Section 08: 140-160 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 140; j < 160; j++) {
			if (i == 0) grid[i][j] = 1;
			else if (i < 2) { if (j > 147) grid[i][j] = 1; }
			else if (i > 3 && i < 5) { if (j > 145) grid[i][j] = 1; }
			else if (i < 6) { if (j > 149) grid[i][j] = 1; }
			else if (i == 9) { if (j == 142) grid[i][j] = 5; else if (j == 143) grid[i][j] = 7; else if (j < 145) grid[i][j] = 1; }
			else if (i == 10) { if (j < 145) grid[i][j] = 1; }
			else if (i > 10) grid[i][j] = 1;
		}
	}

	//Section 09: 160-180 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 160; j < 180; j++) {
			if (i == 0) grid[i][j] = 1;
			else if (i == 1) { if (j < 180) grid[i][j] = 1; }
			else if (i == 2) { if (j < 175) grid[i][j] = 1; }
			else if (i == 3) { if (j < 175) grid[i][j] = 1; }
			else if (i == 4 || i == 5) { if (j >= 169 && j <= 174) grid[i][j] = 1; }
			else if (i == 11) { if (j < 170) grid[i][j] = 1; }
			else if (i > 11) grid[i][j] = 1;
		}
	}

	//Section 10: 180-200 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 180; j < 200; j++) {
			if (i == 0) grid[i][j] = 1;
			else if (i > 10) grid[i][j] = 1;
			else if (i > 9) { if (j > 182) grid[i][j] = 1; }
			else if (i > 8) { if (j > 185) grid[i][j] = 1; }
			else if (i > 7) { if (j > 186) grid[i][j] = 1; }
			else if (i > 6) { if (j > 190) grid[i][j] = 1; }
			else if (i > 5) { if (j > 192) grid[i][j] = 1; }
			//else if (i==5) {if (j==198) grid[i][j] = 8;} where 8 is for placing flag
		}
	}
	grid[8][186] = 8;
	grid[6][191] = 8;
	grid[6][192] = 8;
}

void LabyrinthZone::deployCollectibles() {

	//Deploying Rings:

	rings[0].setPosition(22 * cellSize, 6 * cellSize);
	rings[1].setPosition(23 * cellSize, 6 * cellSize);
	rings[2].setPosition(24 * cellSize, 6 * cellSize);
	rings[3].setPosition(25 * cellSize, 6 * cellSize);
	rings[4].setPosition(26 * cellSize, 6 * cellSize);

	rings[5].setPosition(48 * cellSize, 2 * cellSize);
	rings[6].setPosition(49 * cellSize, 2 * cellSize);
	rings[7].setPosition(50 * cellSize, 2 * cellSize);
	rings[8].setPosition(51 * cellSize, 2 * cellSize);

	rings[9].setPosition(68 * cellSize, 2 * cellSize);
	rings[10].setPosition(69 * cellSize, 2 * cellSize);

	rings[11].setPosition(69 * cellSize, 6 * cellSize);
	rings[12].setPosition(70 * cellSize, 6 * cellSize);
	rings[13].setPosition(71 * cellSize, 6 * cellSize);
	rings[14].setPosition(75 * cellSize, 6 * cellSize);
	rings[15].setPosition(76 * cellSize, 6 * cellSize);
	rings[16].setPosition(77 * cellSize, 6 * cellSize);

	rings[17].setPosition(108 * cellSize, 4 * cellSize);
	rings[18].setPosition(109 * cellSize, 4 * cellSize);
	rings[19].setPosition(110 * cellSize, 4 * cellSize);
	rings[20].setPosition(111 * cellSize, 4 * cellSize);

	rings[21].setPosition(146 * cellSize, 2 * cellSize);
	rings[22].setPosition(146 * cellSize, 1 * cellSize);
	rings[23].setPosition(147 * cellSize, 2 * cellSize);
	rings[24].setPosition(147 * cellSize, 1 * cellSize);

	rings[25].setPosition(162 * cellSize, 6 * cellSize);
	rings[26].setPosition(163 * cellSize, 6 * cellSize);
	rings[27].setPosition(164 * cellSize, 6 * cellSize);
	rings[28].setPosition(165 * cellSize, 6 * cellSize);
	rings[29].setPosition(166 * cellSize, 6 * cellSize);

	//Deploying Special Boosts:
	specialBoost[0].setPosition(10 * cellSize, 6 * cellSize);
	specialBoost[1].setPosition(173 * cellSize, 9 * cellSize);

	//Deploying Extra Lives:
	extraLives[0].setPosition(173 * cellSize, 6 * cellSize);
	extraLives[1].setPosition(18 * cellSize, 6 * cellSize);
}

void LabyrinthZone::deployEnemies() {

	//Deploying crab meat:
	crabMeat[0]->setEnemy(30, 38, 11);
	crabMeat[1]->setEnemy(170, 179, 11);
	crabMeat[2]->setEnemy(81, 85, 8);

	//Deploying bat brain:
	batBrain[0]->setEnemy(12, 20, 8);
	batBrain[1]->setEnemy(91, 100, 6);
	batBrain[2]->setEnemy(193, 200, 5);
}

void LabyrinthZone::levelTriggers() {

	Player* modifyPlayer = sonic;
	if (sonic->get_isPlayerActive()) modifyPlayer = sonic;
	else if (tails->get_isPlayerActive()) modifyPlayer = tails;
	else if (knuckles->get_isPlayerActive()) modifyPlayer = knuckles;

	if (!modifyPlayer) return;

	//Breakable Bridge:
	if (modifyPlayer->get_playerX() >= 38 * cellSize && modifyPlayer->get_playerX() <= 47 * cellSize &&
		modifyPlayer->get_playerY() >= 11 * cellSize - cellSize / 2 && modifyPlayer->get_playerY() <= 12 * cellSize + cellSize / 2 &&
		!isOnBridge1) {
		bridgeClock1.restart();
		isOnBridge1 = true;
	}
	else if (modifyPlayer->get_playerX() >= 50 * cellSize && modifyPlayer->get_playerX() <= 59 * cellSize &&
		modifyPlayer->get_playerY() >= 11 * cellSize - cellSize / 2 && modifyPlayer->get_playerY() <= 12 * cellSize + cellSize / 2 &&
		!isOnBridge2) {
		bridgeClock2.restart();
		isOnBridge2 = true;
	}

	//Switch and Gate:
	if (((modifyPlayer->get_playerX() >= 120 * cellSize - cellSize / 4 && modifyPlayer->get_playerX() <= 121 * cellSize + cellSize / 4) ||
		(modifyPlayer->get_playerX() >= 142 * cellSize - cellSize / 4 && modifyPlayer->get_playerX() <= 143 * cellSize + cellSize / 4)) &&
		(modifyPlayer->get_playerY() >= 8 * cellSize - cellSize / 2 && modifyPlayer->get_playerY() <= 8 * cellSize + cellSize / 2)) {
		switchClock.restart();
		isswitchOn = true;
		grid[8][139] = 0;
	}

	if (isOnBridge1 && bridgeClock1.getElapsedTime().asSeconds() > 0.5) { bridgeFall.play(); for (int j = 40; j < 48; j++) grid[12][j] = 0; }
	if (isOnBridge2 && bridgeClock2.getElapsedTime().asSeconds() > 0.5) { bridgeFall.play();  for (int j = 52; j < 60; j++) grid[12][j] = 0; }
	if (switchClock.getElapsedTime().asSeconds() > 3) { isswitchOn = false; grid[8][139] = 6; }
}