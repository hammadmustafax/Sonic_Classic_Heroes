#pragma once
#include "Header.h"

class Animation {
private:
	int numofAnimations;

	Texture* texture;
	Sprite* sprite;
	Sprite* activeSprite;

	int spriteWidth;
	int spriteHeight;
	int* spriteSheetWidth;
	bool** conditions;

	int currentX;
	int currentAnimation;
	Clock animationClock;

public:
	Animation(int numofAnimations, string* paths, int spriteWidth, int* totalWidth, bool** condition, int spriteHeight = 64) {

		this->numofAnimations = numofAnimations;

		this->texture = new Texture[numofAnimations];
		this->sprite = new Sprite[numofAnimations];
		this->spriteSheetWidth = new int[numofAnimations];
		this->conditions = new bool* [numofAnimations];
		this->spriteWidth = spriteWidth;
		this->spriteHeight = spriteHeight;

		currentX = 0;
		currentAnimation = 0;
		for (int i = 0; i < numofAnimations; i++) {
			texture[i].loadFromFile(paths[i]);
			spriteSheetWidth[i] = totalWidth[i];

			sprite[i].setTexture(texture[i]);
			sprite[i].setTextureRect(IntRect(currentX, 0, spriteWidth, spriteWidth));
			conditions[i] = condition[i];
		}
		activeSprite = &sprite[0];
	}

	Sprite* animate(float off, float playerX, float playerY) {

		if (animationClock.getElapsedTime().asSeconds() > 0.1) {
			animationClock.restart();

			for (int i = 0; i < numofAnimations; i++) {
				if (!*conditions[i]) continue;
				if (currentAnimation == i) {
					currentX += spriteWidth;
					if (currentX >= spriteSheetWidth[i]) currentX = 0;
				}
				else {
					currentAnimation = i;
					currentX = 0;
				}
				activeSprite = &sprite[i];
				activeSprite->setTextureRect(IntRect(currentX, 0, spriteWidth, spriteHeight));
				activeSprite->setPosition(playerX - off, playerY);
			}
		}
		return activeSprite;
	}

	int getCurrentAnimation() {
		return currentAnimation;
	}
};