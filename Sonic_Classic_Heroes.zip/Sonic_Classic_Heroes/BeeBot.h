#pragma once
#include "header.h"
#include "Enemy.h"

class BeeBot : public Enemy {
private:
	Texture bulletTexture;
	Sprite bulletSprite;
	bool isBulletActive;
	int bulletSize;
	float bulletX; float velocityX;
	float bulletY; float velocityY;
	float bulletSpeed; float bulletGravity;
	bool bulletJustStarted;

	bool flyingUp;
	float flyHeight;
	float baseY;
	//Clock CollisionClock;

public:
	BeeBot() {

		hp = 5;
		enemySpeed = 4;
		bulletGravity = 2;
		bulletSpeed = 15;
		isBulletActive = false;
		bulletSize = 16;
		bulletJustStarted = false;

		numofAnimations = 4;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/BeebotMovingLeft.png"; paths[1] = "Data/BeebotMovingRight.png";
		paths[2] = "Data/BeebotAttackingLeft.png"; paths[3] = "Data/BeebotAttackingRight.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 192; totalWidth[1] = 192; totalWidth[2] = 128; totalWidth[3] = 128;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);

		bulletTexture.loadFromFile("Data/CrabMeatBullet.png");
		bulletSprite.setTexture(bulletTexture);

		flyingUp = true;
		isFacingRight = true;
		flyHeight = 80;
		isEnemyActive = true;
		bulletCollision = false;
	}

	void setEnemy(float regionLeft, float regionRight, float y) {
		this->regionLeft = regionLeft;
		this->regionRight = regionRight;
		enemyX = (regionRight - (regionRight - regionLeft) / 2) * cellSize;
		enemyY = y * cellSize;
		baseY = enemyY;
	}

	void display(RenderWindow& window, float off) {
		if (isEnemyActive) {

			activeSprite->setPosition(enemyX - off, enemyY);
			window.draw(*activeSprite);

			if (isEnemyAttacking) {
				if (isBulletActive) {
					bulletSprite.setPosition(bulletX - off, bulletY);
					window.draw(bulletSprite);
				}
			}
		}
	}

	bool collision2D(float playerX, float playerY, bool isRollingState , int& score) {
		bool collisionX = (playerX + cellSize >= enemyX && enemyX + cellSize >= playerX);
		bool collisionY = (playerY + cellSize >= enemyY && enemyY + cellSize >= playerY);
		bool bulletCollisionX = (playerX + cellSize >= bulletX && bulletX + cellSize >= playerX);
		bool bulletCollisionY = (playerY + cellSize >= bulletY && bulletY + cellSize >= playerY);

		if (collisionX && collisionY) {
			return true;
		}
		else if (bulletCollisionX && bulletCollisionY && collisionClock.getElapsedTime().asSeconds() > 1) {
			collisionClock.restart();
			bulletCollision = true;
			return true;
		}
		return false;
	}

	void movement(float time) {

		if (flyingUp) {
			enemyY -= enemySpeed * time / 30;
			if (enemyY <= baseY - flyHeight)
				flyingUp = false;
		}
		else {
			enemyY += enemySpeed * time / 30;
			if (enemyY >= baseY + flyHeight)
				flyingUp = true;
		}

		if (isFacingRight) {
			enemyX += enemySpeed * time / 30;
			if (enemyX >= regionRight * cellSize)
				isFacingRight = false;
		}
		else {
			enemyX -= enemySpeed * time / 30;
			if (enemyX <= regionLeft * cellSize)
				isFacingRight = true;
		}
	}

	void attack(float time, float playerX, float playerY) {

		if (bulletJustStarted) {
			bulletX = enemyX - 15; bulletY = enemyY - 10;


			velocityX = -1 * bulletSpeed;
			velocityY = -3;

			bulletJustStarted = false;
		}

		bulletX += velocityX * time / 30;
		bulletY += velocityY * time / 30;

		velocityY += bulletGravity * time / 30;

		if (bulletX < regionLeft * cellSize || bulletX > regionRight * cellSize) {
			isBulletActive = false;
		}

	}

	void update(float time, float playerX = 0, float playerY = 0 , int** grid = nullptr , int vol = 0) {

		EnemyKill.setVolume(vol);
		movement(time);
		bulletCollision = false;

		// beebot attacks after 5s
		if (attackClock.getElapsedTime().asSeconds() >= 5 && !isBulletActive) {
			isEnemyAttacking = true;
			bulletJustStarted = true;
			isBulletActive = true;
			attackClock.restart();
		}

		if (isBulletActive) {
			attack(time, playerX, playerY);
		}
	}

	void animate(float off) {

		if (!isEnemyActive) return;
		for (int i = 0; i < numofAnimations; i++) conditionsforAnimations[i] = false;

		if (!isFacingRight) {
			if (!isEnemyAttacking) conditionsforAnimations[0] = true;
			else conditionsforAnimations[2] = true;
		}
		else {
			if (!isEnemyAttacking) conditionsforAnimations[1] = true;
			else conditionsforAnimations[3] = true;
		}
		activeSprite = animation->animate(off, enemyX, enemyY);
	}
};
