#include <fstream>
#include "Game.h"
#include "LabyrinthZone.h"
#include "IceCapZone.h"
#include "DeathEggZone.h"
#include "BossLevel.h"
#include "SonicTheHedgeHog.h"
#include "TailsTheFox.h"
#include "KnucklesTheEchidna.h"
#include "Header.h"

Game::Game(int screen_x, int screen_y) {
	
	score = 0;
	volume = 50;
	playerName = "";

	levelNumber = 4;
	this->screen_x = screen_x;
	this->screen_y = screen_y;

	mainMenu = new MainMenu(screen_x, screen_y, volume);
	leaderBoard = new LeaderBoard(screen_x, screen_y);
	options = new Options;

	wonOrLostTexture = new Texture;
	wonOrLostSprite = new Sprite;

	level = nullptr;
	sonic = nullptr;
	tails = nullptr;
	knuckles = nullptr;

	isGameStart = false;
	loadNextLevel = true;
	islevelLost = false;

	takeNameInput = true;
	takeOldState = true;
}

Game::~Game() {
	delete mainMenu; mainMenu = nullptr;
	delete leaderBoard; leaderBoard = nullptr;
	delete options; options = nullptr;
	delete sonic; sonic = nullptr;
	delete tails; tails = nullptr;
	delete knuckles; knuckles = nullptr;
	if (level) delete level; level = nullptr;

	delete wonOrLostTexture; wonOrLostTexture = nullptr;
	delete wonOrLostSprite; wonOrLostSprite = nullptr;
}

bool Game::get_exitGame() {
	return mainMenu->get_exitGame();
}

void Game::set_exitGame(bool exitGame) {
	mainMenu->set_exitGame(exitGame);
}

void Game::loadLevel() {

	if (level != nullptr) delete level;
	if (levelNumber == 1) {
		sonic = new SonicTheHedgeHog(true);
		tails = new TailsTheFox(false);
		knuckles = new KnucklesTheEchidna(false);
		this->level = new LabyrinthZone(levelNumber, sonic, tails, knuckles);
	}
	else if (levelNumber == 2) {
		this->level = new IceCapZone(levelNumber, sonic, tails, knuckles);
	}
	else if (levelNumber == 3) {
		this->level = new DeathEggZone(levelNumber, sonic, tails, knuckles); 
	}
	else if (levelNumber == 4) {
		this->level = new BossLevel(levelNumber, sonic); 
	}

	level->setCurrentLevel(levelNumber);
	loadNextLevel = false;
	islevelLost = false;
}

void Game::update(float time) {

	if (mainMenu && mainMenu->get_ismainMenuActive() && mainMenu->checkForSavedGame())
		mainMenu->set_isSavedStatePresent(true);

	mainMenu->update(volume);

	if (loadNextLevel) loadLevel();
	if (level) {
		level->update(time, score, volume);
		if (level->getLevelEnd()) {
			if (level->getLevelWon()) {
				if (levelNumber == 4) {
					isGameStart = false;
				}
				else {
					levelNumber++;
					loadNextLevel = true;
				}
			}
			else if (level->getLevelLost()) {
				islevelLost = true;
				isGameStart = false;
			}
		}
	}
}

void Game::handleInput(RenderWindow& window, Event& event, float time) {
	if (mainMenu && mainMenu->get_ismainMenuActive()) {
		mainMenu->handleInput(window, event);
	}
	else if (mainMenu && mainMenu->get_openOptions()) {
		options->handleInput(window, event, volume);
	}
	else if (mainMenu && mainMenu->get_openScoreBoard()) {
		leaderBoard->handleInput(window, event);
	}
	else if (mainMenu && mainMenu->get_startNewGame()) {

		isGameStart = true;
		if (takeNameInput) {
			playerName = mainMenu->takeNameInput(window);
			takeNameInput = false;
			cout << playerName << endl;
		}

		if (level == nullptr) return;
		level->handleInput(window, event, time);
	}
	else if (mainMenu->get_startSavedGame()) {
		isGameStart = true;
		if (level == nullptr) return;
		level->handleInput(window, event, time);
	}
}

void Game::display(RenderWindow& window) {
	if (mainMenu->get_ismainMenuActive()) {
		mainMenu->display(window);
	}
	else if (mainMenu->get_openOptions()) {
		options->display(window, volume);
		if (options->get_backtoMenu()) {
			mainMenu->set_ismainMenuActive(true);
			mainMenu->set_openOptions(false);
			options->set_backtoMenu(false);
		}
	}
	else if (mainMenu->get_openScoreBoard()) {
		leaderBoard->display(window);
		if (leaderBoard->get_backtoMenu()) {
			mainMenu->set_ismainMenuActive(true);
			mainMenu->set_openScoreBoard(false);
			leaderBoard->set_backtoMenu(false);
		}
	}
	else if (mainMenu->get_startNewGame()) {
		if (level) level->display(window, score);
		if (islevelLost || !isGameStart) {

			leaderBoard->compareScores(score, playerName);
			
			if (islevelLost) wonOrLostDisplay(0, window);
			else wonOrLostDisplay(1, window);

			wonOrLostClock.restart();
			while (wonOrLostClock.getElapsedTime().asSeconds() < 3) {

				bool back = false;
				Event exit;
				while (window.pollEvent(exit)) {
					if (exit.type == Event::KeyPressed && exit.key.code == Keyboard::Escape) back = true;
				}
				if (back) break;
				window.clear();
				leaderBoard->display(window);
				window.display();
			}

			mainMenu->set_ismainMenuActive(true);
			mainMenu->set_startNewGame(false);

			if (level) delete level;
			if (sonic) delete sonic;
			if (tails) delete tails;
			if (knuckles) delete knuckles;

			islevelLost = false; isGameStart = false;
			levelNumber = 1; level = nullptr;
			sonic = nullptr; tails = nullptr; knuckles = nullptr;
			loadNextLevel = true; takeNameInput = true; score = 0;
		}
	}
	else if (mainMenu->get_startSavedGame()) {
		
		if (takeOldState) {
			retrieveGame();
			takeOldState = false;
		}
		
		if (level) level->display(window, score);
		if (islevelLost || !isGameStart) {

			leaderBoard->compareScores(score, playerName);
			if (islevelLost) wonOrLostDisplay(0, window);
			else wonOrLostDisplay(1, window);

			wonOrLostClock.restart();
			while (wonOrLostClock.getElapsedTime().asSeconds() < 3) {

				bool back = false;
				Event exit;
				while (window.pollEvent(exit)) {
					if (exit.type == Event::KeyPressed && exit.key.code == Keyboard::Escape) back = true;
				}
				if (back) break;
				window.clear();
				leaderBoard->display(window);
				window.display();
			}

			mainMenu->set_ismainMenuActive(true);
			mainMenu->set_startNewGame(false);

			if (level) delete level;
			if (sonic) delete sonic;
			if (tails) delete tails;
			if (knuckles) delete knuckles;

			islevelLost = false; isGameStart = false;
			levelNumber = 1; level = nullptr;
			sonic = nullptr; tails = nullptr; knuckles = nullptr;
			loadNextLevel = true; takeNameInput = true; score = 0;
		}
	}
}

void Game::wonOrLostDisplay(bool condition, RenderWindow& window) {

	wonOrLostClock.restart();
	while (wonOrLostClock.getElapsedTime().asSeconds() < 3) {

		Event exit;
		while (window.pollEvent(exit)) {
			if (exit.type == Event::KeyPressed && exit.key.code == Keyboard::Escape) return;
		}

		if (condition == 0) { //Player has lost the game
			wonOrLostTexture->loadFromFile("Data/gameover.png");
			wonOrLostSprite->setTexture(*wonOrLostTexture);
			wonOrLostSprite->setScale(1.5, 1.5);
			wonOrLostSprite->setPosition(305, 300);
			window.clear();
			window.draw(*wonOrLostSprite);
			window.display();
		}
		else { //Player has won the game
			wonOrLostTexture->loadFromFile("Data/winner.png");
			wonOrLostSprite->setTexture(*wonOrLostTexture);
			window.clear();
			window.draw(*wonOrLostSprite);
			window.display();
		}
	}
}

void Game::saveGame() {

	fstream saveFile;
	saveFile.open("savedgame.txt", ios::out);

	saveFile << playerName << endl;
	saveFile << score << endl;
	saveFile << volume << endl;
	saveFile << levelNumber << endl;

	saveCharacters(saveFile, sonic);
	saveCharacters(saveFile, tails);
	saveCharacters(saveFile, knuckles);

	saveLevel(saveFile, level);

	saveFile.close();
}

void Game::saveCharacters(fstream& saveFile, Player* player) {

	if (player == nullptr) return;

	saveFile << player->getNumberOfAnimations() << endl;

	saveFile << player->getPlayerHP() << endl;
	saveFile << player->getPlayerSpeed() << endl;

	saveFile << player->getIsPlayerActive() << endl;
	saveFile << player->getPlayerX() << endl;
	saveFile << player->getPlayerY() << endl;

	saveFile << player->getIsHit() << endl;
	saveFile << player->getInvincibilityTimer() << endl;

	saveFile << player->getIsPowerUpActive() << endl;
	saveFile << player->getPowerUpClock() << endl;

	saveFile << player->getSpaceAlreadyPressed() << endl;

	saveFile << player->getLevelWidth() << endl;
	saveFile << player->getLevelStart() << endl;

	saveFile << player->getIsPlayerJumping() << endl;
	saveFile << player->getIsAbilityActive() << endl;
	saveFile << player->getIsMoving() << endl;
	saveFile << player->getIsFacingRight() << endl;

	saveFile << player->getVelocityY() << endl;
	saveFile << player->getOnGround() << endl;

	saveFile << player->getLeftcollision() << endl;
	saveFile << player->getRightcollision() << endl;
	saveFile << player->getTopcollision() << endl;
	saveFile << player->getBottomcollision() << endl;
}

void Game::saveLevel(fstream& saveFile, Level* level) {

	if (level == nullptr) return;

}

void Game::retrieveGame() {
	
}



