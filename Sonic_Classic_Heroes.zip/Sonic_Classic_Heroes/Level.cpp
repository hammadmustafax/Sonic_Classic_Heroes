#include "Header.h"
#include "Level.h"
#include "SonicTheHedgeHog.h"
#include "Rings.h"
#include "CrabMeat.h"

Level::Level(int levelNumber, Player* one, Player* two, Player* three) : sonic(one), tails(two), knuckles(three) {

	rings = nullptr; specialBoost = nullptr; extraLives = nullptr;
	crabMeat = nullptr; motoBug = nullptr; beeBot = nullptr; batBrain = nullptr;

	currentLevel = levelNumber;
	isLevelEnd = false; isLevelLost = false; isLevelWon = false;

	levelStart = false;


	eggStinger = nullptr;

	numofRings = 0; numofSpecialBoosts = 0; numofExtraLives = 0;
	numOfCrabMeat = 0; numOfBeeBot = 0; numOfMotoBug = 0; numOfBatBrain = 0;

	levelTime = 0;
	offset = 0;

	ringsLeft = 0;
	rows = 14;
	cols = 0;
	cellSize = 64;
	grid = nullptr;

	if (sonic != nullptr) { sonic->set_playerX(10); sonic->set_playerY(8 * cellSize); }
	if (tails != nullptr) { tails->set_playerX(7); tails->set_playerY(8 * cellSize); }
	if (knuckles != nullptr) { knuckles->set_playerX(5); knuckles->set_playerY(8 * cellSize); }

	currentIndex = 0;
	for (int i = 0; i < size; i++) {
		posX[i] = 0; posY[i] = 0;
	}

	delayInFollowing = 0.1;
	totalData = 0;

	isswitchOn = false;
	isOnBridge1 = false;
	isOnBridge2 = false;

	gateTexture.loadFromFile("Data/Gate.png"); gateSprite.setTexture(gateTexture);
	spikeTexture.loadFromFile("Data/spike.png"); spikeSprite.setTexture(spikeTexture);

	bridgeFall.openFromFile("Music/falling.mp3");
}

void Level::setLevelEnd(bool isLevelEnd) {
	this->isLevelEnd = isLevelEnd;
}

void Level::setLevelLost(bool isLevelLost) {
	this->isLevelLost = isLevelLost;
}

void Level::setLevelWon(bool isLevelWon) {
	this->isLevelWon = isLevelWon;
}

void Level::setCurrentLevel(int currentLevel) {
	this->currentLevel = currentLevel;
}

bool Level::getLevelEnd() {
	return isLevelEnd;
}

bool Level::getLevelLost() {
	return isLevelLost;
}

bool Level::getLevelWon() {
	return isLevelWon;
}

int Level::getCurrentLevel() {
	return currentLevel;
}

void Level::handleInput(RenderWindow& window, Event& event, float time) {

	if (event.type == Event::Closed) window.close();
	else if (event.type == Event::KeyPressed && event.key.code == Keyboard::Z && currentLevel != 4) {
		if (sonic->get_isPlayerActive()) {
			if (tails != nullptr) {
				sonic->set_isPlayerActive(false);
				tails->set_isPlayerActive(true);

				float tempX = sonic->get_playerX(), tempY = sonic->get_playerY();
				sonic->set_playerX(tails->get_playerX());
				sonic->set_playerY(tails->get_playerY());

				tails->set_playerX(tempX); tails->set_playerY(tempY);
			}
		}
		else if (tails->get_isPlayerActive()) {

			if (knuckles != nullptr) {
				tails->set_isPlayerActive(false);
				knuckles->set_isPlayerActive(true);

				float tempX = tails->get_playerX(), tempY = tails->get_playerY();
				tails->set_playerX(knuckles->get_playerX());
				tails->set_playerY(knuckles->get_playerY());

				knuckles->set_playerX(tempX); knuckles->set_playerY(tempY);
			}
		}
		else if (knuckles->get_isPlayerActive()) {

			if (sonic != nullptr) {
				knuckles->set_isPlayerActive(false);
				sonic->set_isPlayerActive(true);

				float tempX = knuckles->get_playerX(), tempY = knuckles->get_playerY();
				knuckles->set_playerX(sonic->get_playerX());
				knuckles->set_playerY(sonic->get_playerY());

				sonic->set_playerX(tempX); sonic->set_playerY(tempY);
			}
		}
	}

	if (sonic->get_isPlayerActive()) sonic->HandleEvent(window, event, time);
	else if (tails->get_isPlayerActive()) tails->HandleEvent(window, event, time);
	else if (knuckles->get_isPlayerActive()) knuckles->HandleEvent(window, event, time);
}

void Level::display(RenderWindow& window, int& score) {

	Player* modifyPlayer = sonic;
	if (sonic && sonic->get_isPlayerActive()) modifyPlayer = sonic;
	else if (tails && tails->get_isPlayerActive()) modifyPlayer = tails;
	else if (knuckles && knuckles->get_isPlayerActive()) modifyPlayer = knuckles;

	window.draw(backgroundSprite);

	int stx = offset / cellSize;
	if (stx < 0) stx = 0;

	int enx = stx + 21;
	if (enx > cols) enx = cols;

	for (int i = 0; i < rows; i++) {
		for (int j = stx; j < enx; j++) {

			if (grid[i][j] == 1) {
				brick1Sprite.setPosition(j * cellSize - offset, i * cellSize);
				window.draw(brick1Sprite);
			}
			else if (grid[i][j] == 2) {
				brick2Sprite.setPosition(j * cellSize - offset, i * cellSize);
				window.draw(brick2Sprite);
			}
			else if (grid[i][j] == 3) {
				brick3Sprite.setPosition(j * cellSize - offset, i * cellSize);
				window.draw(brick3Sprite);
			}
			else if (grid[i][j] == 4) {
				bridgeSprite.setPosition(j * cellSize - offset, i * cellSize);
				window.draw(bridgeSprite);
			}
			else if (grid[i][j] == 5) {
				if (isswitchOn) switchSprite.setPosition(j * cellSize - offset, i * cellSize + 10 * switchClock.getElapsedTime().asSeconds());
				else switchSprite.setPosition(j * cellSize - offset, i * cellSize);
				window.draw(switchSprite);
			}
			else if (grid[i][j] == 6) {
				if (!isswitchOn) {
					gateSprite.setPosition(j * cellSize - offset, i * cellSize);
					window.draw(gateSprite);
				}
			}
			else if (grid[i][j] == 8) {
				spikeSprite.setPosition(j * cellSize - offset, i * cellSize);
				window.draw(spikeSprite);
			}
		}
	}

	if (extraLives) { for (int i = 0; i < numofExtraLives; i++) extraLives[i].display(window, offset); }
	if (specialBoost) { for (int i = 0; i < numofSpecialBoosts; i++) specialBoost[i].display(window, offset); }
	if (rings) { for (int i = 0; i < numofRings; i++) rings[i].display(window, offset); }
	if (crabMeat) { for (int i = 0; i < numOfCrabMeat; i++) crabMeat[i]->display(window, offset); }
	if (batBrain) { for (int i = 0; i < numOfBatBrain; i++) batBrain[i]->display(window, offset); }
	if (beeBot) { for (int i = 0; i < numOfBeeBot; i++) beeBot[i]->display(window, offset); }
	if (motoBug) { for (int i = 0; i < numOfMotoBug; i++) motoBug[i]->display(window, offset); }
	if (eggStinger) { eggStinger[0]->display(window, offset); }

	Font font1; font1.loadFromFile("Fonts/arial.ttf");
	Font font2; font2.loadFromFile("Fonts/ARCADE_I.TTF");

	Texture hpTexture, timeTexture, ringsTexture;
	Sprite hpSprite, timeSprite, ringsSprite;
	hpTexture.loadFromFile("Data/ExtraLife.png"); hpSprite.setTexture(hpTexture);
	timeTexture.loadFromFile("Data/clock.png"); timeSprite.setTexture(timeTexture);
	ringsTexture.loadFromFile("Data/rings.png"); ringsSprite.setTexture(ringsTexture); ringsSprite.setTextureRect(IntRect(0, 0, 64, 64));

	Text ringsText, hpText, scoreText, timeText;

	hpSprite.setPosition(30, 70);
	hpText.setString(to_string(modifyPlayer->getPlayerHP()));
	hpText.setFont(font2); hpText.setCharacterSize(36); hpText.setFillColor(Color::White); hpText.setPosition(46, 78);
	window.draw(hpSprite); window.draw(hpText);

	timeSprite.setPosition(210, 60); timeSprite.setScale(3.8, 3.8);
	timeText.setString(to_string(int(levelTimeClock.getElapsedTime().asSeconds())) + '/' + to_string(levelTime));
	timeText.setFont(font2); timeText.setCharacterSize(36); timeText.setFillColor(Color::White); timeText.setPosition(283, 82);
	if (currentLevel != 4) { window.draw(timeSprite); window.draw(timeText); }

	ringsSprite.setPosition(590, 75); ringsSprite.setScale(0.9, 0.9);
	ringsText.setString(to_string(numofRings - ringsLeft) + '/' + to_string(numofRings));
	ringsText.setFont(font2); ringsText.setCharacterSize(36); ringsText.setFillColor(Color::Cyan); ringsText.setPosition(658, 81);
	if (currentLevel != 4) { window.draw(ringsSprite); window.draw(ringsText); }

	scoreText.setPosition(910, 78);
	scoreText.setString("Score: " + to_string(score));
	scoreText.setFont(font2); scoreText.setCharacterSize(36); scoreText.setFillColor(Color::Green);
	window.draw(scoreText);

	if (!levelStart) levelTimeClock.restart();

	if (sonic) sonic->display(window, sonic->get_playerX() - offset);
	if (tails) tails->display(window, tails->get_playerX() - offset);
	if (knuckles) knuckles->display(window, knuckles->get_playerX() - offset);
}

void Level::update(float time, int& score, int volume) {

	LevelMusic.setVolume(volume);
	if (LevelMusic.getStatus() != SoundSource::Playing && levelStart) {
		LevelMusic.play();
	}

	Player* modifyPlayer = sonic;
	if (sonic && sonic->get_isPlayerActive()) modifyPlayer = sonic;
	else if (tails && tails->get_isPlayerActive()) modifyPlayer = tails;
	else if (knuckles && knuckles->get_isPlayerActive()) modifyPlayer = knuckles;

	int min = 10;
	if (sonic) {
		int temp = sonic->getPlayerHP();
		if (temp < min) min = temp;
	}
	if (tails) {
		int temp = tails->getPlayerHP();
		if (temp < min) min = temp;
	}
	if (knuckles) {
		int temp = knuckles->getPlayerHP();
		if (temp < min) min = temp;
	}

	if (sonic) {
		sonic->setPlayerHP(min);
	}
	if (tails) {
		tails->setPlayerHP(min);
	}
	if (knuckles) {
		knuckles->setPlayerHP(min);
	}

	if (!modifyPlayer) return;

	float xCord = 0, yCord = 0;
	xCord = modifyPlayer->get_playerX();
	yCord = modifyPlayer->get_playerY();

	int screen_x = 20 * cellSize;

	if (xCord <= screen_x / 2) offset = 0;
	else if (xCord >= cols * cellSize - screen_x / 2) offset = cols * cellSize - screen_x;
	else offset = xCord - screen_x / 2;

	modifyPlayer->setIsLevelStart(&levelStart);

	if (modifyPlayer->getPlayerHP() == 0) {
		isLevelEnd = true;
		isLevelLost = true;
		return;
	}

	if (currentLevel != 4) {
		if (xCord >= (cols - 1) * cellSize && ringsLeft == 0) {
			isLevelEnd = true;
			isLevelWon = true;
			return;
		}
		if (yCord >= (rows - 2) * cellSize + cellSize / 2 || levelTimeClock.getElapsedTime().asSeconds() >= levelTime) {
			isLevelEnd = true;
			isLevelLost = true;
			return;
		}
	}
	else {
		if (eggStinger && !eggStinger[0]->getIsEnemyActive()) {
			isLevelEnd = true;
			isLevelWon = true;
		}
		else if (sonic && (!sonic->get_isPlayerActive() || yCord >= (rows - 2) * cellSize + cellSize / 2 || sonic->getPlayerHP() == 0)) {
			isLevelEnd = true;
			isLevelLost = true;
		}
	}

	if (rings && numofRings > 0) {
		for (int i = 0; i < numofRings; i++) {
			if (rings[i].getisCollectibleActive() && rings[i].Collision(modifyPlayer->get_playerX(), modifyPlayer->get_playerY())) ringsLeft--;
			rings[i].update(volume);
			rings[i].nextFrame(offset);
		}
	}

	if (extraLives && numofExtraLives > 0) {
		for (int i = 0; i < numofExtraLives; i++) {
			if (extraLives[i].getisCollectibleActive() && extraLives[i].Collision(modifyPlayer->get_playerX(), modifyPlayer->get_playerY())) {

				if (sonic) sonic->setPlayerHP(sonic->getPlayerHP() + 1);
				if (tails) tails->setPlayerHP(tails->getPlayerHP() + 1);
				if (knuckles) knuckles->setPlayerHP(knuckles->getPlayerHP() + 1);
			}
			extraLives[i].nextFrame(offset);
		}
	}

	if (specialBoost && numofSpecialBoosts > 0) {
		for (int i = 0; i < numofSpecialBoosts; i++) {
			if (specialBoost[i].getisCollectibleActive() && specialBoost[i].Collision(modifyPlayer->get_playerX(), modifyPlayer->get_playerY())) {
				if (sonic && sonic->get_isPlayerActive()) {
					sonic->setSpeed(sonic->get_speed() + 4);
					sonic->setIsPowerUpActive(true);
					sonic->setPowerUpClock();
				}
				else if (tails && tails->get_isPlayerActive()) {
					tails->setMaxFlyTime(tails->getMaxFlyTime() + 4);
					tails->setIsPowerUpActive(true);
					tails->setPowerUpClock();
				}
				else if (knuckles && knuckles->get_isPlayerActive()) {
					knuckles->setInvincibilityTime(knuckles->getInvincibilityTime() + 15);
					knuckles->setIsPowerUpActive(true);
					knuckles->setPowerUpClock();
				}
			}
			specialBoost[i].nextFrame(offset);
		}
	}

	if (crabMeat && numOfCrabMeat > 0) {
		for (int i = 0; i < numOfCrabMeat; i++) {
			if (crabMeat[i]->getIsEnemyActive()) {
				crabMeat[i]->update(time, modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), grid, volume);
				crabMeat[i]->animate(offset);

				if (crabMeat[i]->collision2D(modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), modifyPlayer->getIsPlayerJumping(), score)) {

					if (modifyPlayer->getIsPlayerJumping() && !crabMeat[i]->getBulletCollision()) {
						crabMeat[i]->setEnemyHP(0);
						crabMeat[i]->enemyKillMusic(true);
						score += 40;
						crabMeat[i]->setIsEnemyActive(false);

					}
					else if (modifyPlayer->getPlayerHP() > 0) {

						if (!modifyPlayer->getIsHit())
						{
							modifyPlayer->resetCollisionClock();
							sonic->setPlayerHP(sonic->getPlayerHP() - 1);
							tails->setPlayerHP(tails->getPlayerHP() - 1);
							knuckles->setPlayerHP(knuckles->getPlayerHP() - 1);
							modifyPlayer->playerDamageMusic();
							modifyPlayer->setIsHit(true);
						}
					}
				}
			}
		}
	}

	if (batBrain && numOfBatBrain > 0) {
		for (int i = 0; i < numOfBatBrain; i++) {
			if (batBrain[i]->getIsEnemyActive()) {
				batBrain[i]->update(time, modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), grid, volume);
				batBrain[i]->animate(offset);
				if (batBrain[i]->collision2D(modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), modifyPlayer->getIsPlayerJumping(), score)) {
					if (modifyPlayer->getIsPlayerJumping())
					{
						batBrain[i]->setEnemyHP(0);
						batBrain[i]->enemyKillMusic(true);
						score += 30;
						batBrain[i]->setIsEnemyActive(false);

					}
					else if (modifyPlayer->getPlayerHP() > 0) {

						if (!modifyPlayer->getIsHit())
						{
							modifyPlayer->resetCollisionClock();
							sonic->setPlayerHP(sonic->getPlayerHP() - 1);
							tails->setPlayerHP(tails->getPlayerHP() - 1);
							knuckles->setPlayerHP(knuckles->getPlayerHP() - 1);
							modifyPlayer->playerDamageMusic();
							modifyPlayer->setIsHit(true);
						}
					}
				}
			}
		}
	}

	if (beeBot && numOfBeeBot > 0) {
		for (int i = 0; i < numOfBeeBot; i++) {
			if (beeBot[i]->getIsEnemyActive()) {
				beeBot[i]->update(time, modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), grid, volume);
				beeBot[i]->animate(offset);
				if (beeBot[i]->collision2D(modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), modifyPlayer->getIsPlayerJumping(), score)) {
					if (modifyPlayer->getIsPlayerJumping() && !beeBot[i]->getBulletCollision()) {
						beeBot[i]->setEnemyHP(0);
						beeBot[i]->enemyKillMusic(true);
						score += 50;
						beeBot[i]->setIsEnemyActive(false);
					}
					else if (modifyPlayer->getPlayerHP() > 0) {

						if (!modifyPlayer->getIsHit())
						{
							modifyPlayer->resetCollisionClock();
							sonic->setPlayerHP(sonic->getPlayerHP() - 1);
							tails->setPlayerHP(tails->getPlayerHP() - 1);
							knuckles->setPlayerHP(knuckles->getPlayerHP() - 1);
							modifyPlayer->playerDamageMusic();
							modifyPlayer->setIsHit(true);
						}

					}
				}
			}
		}
	}

	if (motoBug && numOfMotoBug > 0) {
		for (int i = 0; i < numOfMotoBug; i++) {
			if (motoBug[i]->getIsEnemyActive()) {
				motoBug[i]->update(time, modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), grid, volume);
				motoBug[i]->animate(offset);
				if (motoBug[i]->collision2D(modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), modifyPlayer->getIsPlayerJumping(), score)) {
					if (modifyPlayer->getIsPlayerJumping())
					{
						motoBug[i]->setEnemyHP(0);
						motoBug[i]->enemyKillMusic(true);
						score += 20;
						motoBug[i]->setIsEnemyActive(false);
					}
					else if (modifyPlayer->getPlayerHP() > 0) {

						if (!modifyPlayer->getIsHit())
						{
							modifyPlayer->resetCollisionClock();
							sonic->setPlayerHP(sonic->getPlayerHP() - 1);
							tails->setPlayerHP(tails->getPlayerHP() - 1);
							knuckles->setPlayerHP(knuckles->getPlayerHP() - 1);
							modifyPlayer->playerDamageMusic();
							modifyPlayer->setIsHit(true);
						}
					}
				}
			}
		}
	}

	if (eggStinger) {
		if (eggStinger[0]->getIsEnemyActive()) {
			eggStinger[0]->update(time, modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), grid, volume);
			eggStinger[0]->animate(offset);
			if (eggStinger[0]->collision2D(modifyPlayer->get_playerX(), modifyPlayer->get_playerY(), modifyPlayer->getIsPlayerJumping(), score)) {

				if (modifyPlayer->getIsPlayerJumping())
				{
					if (modifyPlayer->getCollisionClock() > 1)
					{
						modifyPlayer->resetCollisionClock();
						eggStinger[0]->setEnemyHP(eggStinger[0]->getEnemyHP() - 5);
						eggStinger[0]->enemyKillMusic(true);

						if (eggStinger[0]->getEnemyHP() <= 0)
						{
							score += 500;
							eggStinger[0]->setIsEnemyActive(false);
						}

					}
				}

				else if (modifyPlayer->getPlayerHP() > 0) {
					if (!modifyPlayer->getIsHit())
					{
						modifyPlayer->resetCollisionClock();
						sonic->setPlayerHP(sonic->getPlayerHP() - 1);
						modifyPlayer->playerDamageMusic();
						modifyPlayer->setIsHit(true);
					}
				}
			}
		}
	}

	if (sonic) sonic->setLevelWidth(cols);
	if (tails) tails->setLevelWidth(cols);
	if (knuckles) knuckles->setLevelWidth(cols);

	bool bottomCollision = false;

	int x_axis = (int)(modifyPlayer->getPlayerY() + cellSize) / cellSize;
	int y_axis = (int)(modifyPlayer->getPlayerX()) / cellSize;
	int bottom_collision_left = -1;
	if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < cols)
		bottom_collision_left = grid[x_axis][y_axis];

	x_axis = (int)(modifyPlayer->getPlayerY() + cellSize) / cellSize;
	y_axis = (int)(modifyPlayer->getPlayerX() + cellSize / 2) / cellSize;
	int bottom_collision_right = -1;
	if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < cols)
		bottom_collision_right = grid[x_axis][y_axis];

	x_axis = (int)(modifyPlayer->getPlayerY() + cellSize) / cellSize;
	y_axis = (int)(modifyPlayer->getPlayerX() + cellSize / 4) / cellSize;
	int bottom_collision_mid = -1;
	if (x_axis >= 0 && x_axis < 14 && y_axis >= 0 && y_axis < cols)
		bottom_collision_mid = grid[x_axis][y_axis];

	if ((bottom_collision_left == 8) || (bottom_collision_right == 8) || (bottom_collision_mid == 8)) {
		bottomCollision = true;
	}
	else bottomCollision = false;

	if (modifyPlayer->getPlayerHP() > 0 && bottomCollision) {

		if (!modifyPlayer->getIsHit()) {
			modifyPlayer->resetCollisionClock();
			sonic->setPlayerHP(sonic->getPlayerHP() - 1);
			tails->setPlayerHP(tails->getPlayerHP() - 1);
			knuckles->setPlayerHP(knuckles->getPlayerHP() - 1);
			modifyPlayer->playerDamageMusic();
			modifyPlayer->setIsHit(true);
		}
	}

	if (sonic) {
		sonic->handleUpdate(time, grid, friction, volume, offset, gravity);
		if (sonic->getIsPowerUpActive()) {
			if (sonic->getPowerUpClock() > 8) {
				sonic->setIsPowerUpActive(false);
				sonic->setSpeed(sonic->get_speed() - 4);
			}
		}
	}
	if (tails) {
		tails->handleUpdate(time, grid, friction, volume, offset, gravity);
		if (tails->getIsPowerUpActive()) {
			if (tails->getPowerUpClock() > 11) {
				tails->setIsPowerUpActive(false);
				tails->setMaxFlyTime(tails->getMaxFlyTime() - 4);
			}
		}
	}
	if (knuckles) {
		knuckles->handleUpdate(time, grid, friction, volume, offset, gravity);
		if (knuckles->getIsPowerUpActive()) {
			if (knuckles->getPowerUpClock() > 15) {
				knuckles->setIsPowerUpActive(false);
				knuckles->setInvincibilityTime(knuckles->getInvincibilityTime() - 15);
			}
		}
	}

	levelTriggers();

	if (!eggStinger) autoPlay(time);
	bridgeFall.setVolume(volume);
}

void Level::positionTrack(float playerX, float playerY)
{
	posX[currentIndex] = playerX;
	posY[currentIndex] = playerY;

	currentIndex = (currentIndex + 1) % size;

	if (totalData < size) {
		totalData++;  // total num of pos stored
	}
}

bool Level::trailing(int trailingIdx, float& outX, float& outY) {
	if (trailingIdx >= totalData) {
		return false;
	}

	int index = (currentIndex - 1 - trailingIdx); // prev idx 
	if (index < 0) index += size; //(+size to avoid - values)
	index %= size;

	outX = posX[index];
	outY = posY[index];

	return true;
}

void Level::autoPlay(float time) {

	Player* modifyPlayer = nullptr;
	if (sonic && sonic->get_isPlayerActive()) {
		modifyPlayer = sonic;
	}
	else if (tails && tails->get_isPlayerActive()) {
		modifyPlayer = tails;
	}
	else if (knuckles && knuckles->get_isPlayerActive()) {
		modifyPlayer = knuckles;
	}

	if (modifyPlayer == nullptr) {
		return;
	}

	delayBetweenUpdate += time;
	if (delayBetweenUpdate >= delayInFollowing) {
		positionTrack(modifyPlayer->get_playerX(), modifyPlayer->get_playerY());
		delayBetweenUpdate = 0.0f;
	}

	if (sonic && sonic != modifyPlayer) {
		float posX, posY;
		if (trailing(5, posX, posY)) {
			sonic->set_playerX(posX);
			sonic->set_playerY(posY);
		}
	}

	if (tails && tails != modifyPlayer) {
		float posX, posY;
		if (trailing(25, posX, posY)) {
			tails->set_playerX(posX);
			tails->set_playerY(posY);
		}
	}

	if (knuckles && knuckles != modifyPlayer) {
		float posX, posY;
		if (trailing(45, posX, posY)) {
			knuckles->set_playerX(posX);
			knuckles->set_playerY(posY);
		}
	}
}

void Level::playMusic() {
	LevelMusic.play();
}

Level::~Level() {
	if (crabMeat) {
		for (int i = 0; i < numOfCrabMeat; i++) delete crabMeat[i];
		delete[]crabMeat;
	}

	if (beeBot) {
		for (int i = 0; i < numOfBeeBot; i++) delete beeBot[i];
		delete[]beeBot;
	}

	if (batBrain) {
		for (int i = 0; i < numOfBatBrain; i++) delete batBrain[i];
		delete[]batBrain;
	}

	if (motoBug) {
		for (int i = 0; i < numOfMotoBug; i++) delete motoBug[i];
		delete[]motoBug;
	}

	//if (collectible1) delete collectible1; collectible1 = nullptr;

	sonic = nullptr;
	tails = nullptr;
	knuckles = nullptr;
	if (eggStinger) delete eggStinger; eggStinger = nullptr;

	LevelMusic.stop();
}