#pragma once
#include "Header.h"
#include "Collectibles.h"

class ExtraLives : public Collectibles {
public:
	ExtraLives() {

		numofAnimations = 1;
		string* paths = new string[numofAnimations];
		paths[0] = "Data/ExtraLife.png";

		int* totalWidth = new int[numofAnimations]; int width = 64;
		totalWidth[0] = 64;

		conditionsforAnimations = new bool[numofAnimations];

		bool** condition = new bool* [numofAnimations];
		for (int i = 0; i < numofAnimations; i++) condition[i] = &conditionsforAnimations[i];

		animation = new Animation(numofAnimations, paths, width, totalWidth, condition);
		collectibleHeight = 64;
		collectibleWidth = 64;
		cellSize = 64;

		isCollectibleActive = true;

		currentX = 0;

		collectibleX = 0;
		collectibleY = 0;

		collectableMusic.openFromFile("Music/collectable.wav");
	}
};