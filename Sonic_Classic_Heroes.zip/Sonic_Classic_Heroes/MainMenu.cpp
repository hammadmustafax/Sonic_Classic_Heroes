#include <fstream>
#include "MainMenu.h"
#include "Header.h"

MainMenu::MainMenu(int screen_x, int screen_y, int&volume) {
	
	menuOptions = 5;
	optionSelected = 0;

	startNewGame = false;
	startSavedGame = false;
	openScoreBoard = false;
	openOptions = false;
	exitGame = false;

	ismainMenuActive = true;
	isSavedStatePresent = false;

	this->screen_x = screen_x;
	this->screen_y = screen_y;

	font1 = new Font, font2 = new Font;
	backgroundTexture = new Texture; backgroundSprite = new Sprite;
	nameOfGame = new Text; menuHeading = new Text; copyright = new Text; menu = new Text[menuOptions];
	box = new RectangleShape[menuOptions]; layer = new RectangleShape(Vector2f(screen_x, screen_y));
	options = new string[menuOptions];

	menuMusic.openFromFile("Music/mainmenu.mp3");
	menuMusic.play();

	makeMenu();
}

MainMenu::~MainMenu() {
	delete font1; font1 = nullptr;
	delete font2; font2 = nullptr;
	delete backgroundTexture; backgroundTexture = nullptr; 
	delete backgroundSprite; backgroundSprite = nullptr;
	delete nameOfGame; nameOfGame = nullptr;
	delete menuHeading; menuHeading = nullptr;
	delete copyright; copyright = nullptr;
	delete[]menu; menu = nullptr;
	delete[]box; box = nullptr;
	delete layer; layer = nullptr;
	delete[]options; options = nullptr;
}

void MainMenu::set_startNewGame(bool startNewGame){
	this->startNewGame = startNewGame;
}

void MainMenu::set_startSavedGame(bool startSavedGame) {
	
	this->startSavedGame = startSavedGame;
}

void MainMenu::set_openScoreBoard(bool openScoreBoard) {
	this->openScoreBoard = openScoreBoard;
}

void MainMenu::set_openOptions(bool openOptions) {
	this->openOptions = openOptions;
}

void MainMenu::set_exitGame(bool exitGame) {
	this->exitGame = exitGame;
}

void MainMenu::set_ismainMenuActive(bool ismainMenuActive) {
	this->ismainMenuActive = ismainMenuActive;
}

void MainMenu::set_isSavedStatePresent(bool isSavedStatePresent) {
	this->isSavedStatePresent = isSavedStatePresent;
}

bool MainMenu::get_startNewGame() {
	return startNewGame;
}

bool MainMenu::get_startSavedGame() {
	return startSavedGame;
}

bool MainMenu::get_openScoreBoard() {
	return openScoreBoard;
}

bool MainMenu::get_openOptions() {
	return openOptions;
}

bool MainMenu::get_exitGame() {
	return exitGame;
}

//bool MainMenu::get_wantsTostartGame() {
//	return wantsTostartGame;
//}

bool MainMenu::get_ismainMenuActive() {
	return ismainMenuActive;
}

bool MainMenu::get_isSavedStatePresent() {
	return isSavedStatePresent;
}

void MainMenu::display(RenderWindow& window) {

	window.clear();
	window.draw(*backgroundSprite);
	window.draw(*layer);
	window.draw(*nameOfGame);
	window.draw(*menuHeading);
	window.draw(*copyright);

	for (int i = 0; i < menuOptions; i++) {
		window.draw(box[i]);
		window.draw(menu[i]);
	}
}

void MainMenu::handleInput(RenderWindow& window, Event& event) {

	menu[optionSelected].setFillColor(Color::Green);

	if (event.type == Event::Closed) window.close();

	else if (event.type == Event::KeyPressed) {

		if (event.key.code == Keyboard::Up) {

			menu[optionSelected].setFillColor(Color::White);
			optionSelected = (optionSelected - 1 + menuOptions) % menuOptions;
			menu[optionSelected].setFillColor(Color::Green);

			if (!isSavedStatePresent) menu[1].setFillColor(Color(128, 128, 128));
		}

		else if (event.key.code == Keyboard::Down) {

			menu[optionSelected].setFillColor(Color::White);
			optionSelected = (optionSelected + 1) % menuOptions;
			menu[optionSelected].setFillColor(Color::Green);

			if (!isSavedStatePresent) menu[1].setFillColor(Color(128, 128, 128));
		}

		else if (event.key.code == Keyboard::Enter) {

			if (options[optionSelected] == "New Game") {
				startNewGame = true;
				ismainMenuActive = false;
				menuMusic.stop();
			}

			else if (options[optionSelected] == "Continue Game") {
				if (isSavedStatePresent) {
					startSavedGame = true;
					ismainMenuActive = false;
					menuMusic.stop();
				}
			}

			else if (options[optionSelected] == "High Scores") {
				openScoreBoard = true;
				ismainMenuActive = false;
			}
			
			else if (options[optionSelected] == "Options") {
				openOptions = true;
				ismainMenuActive = false;
			}
			else
				window.close();
		}
	}
}

void MainMenu::makeMenu() {

	font1->loadFromFile("Fonts/ARCADE_I.TTF");
	font2->loadFromFile("Fonts/arial.ttf");

	backgroundTexture->loadFromFile("MainMenuSprites/bg.jpg");
	backgroundSprite->setTexture(*backgroundTexture);

	nameOfGame->setFont(*font1);
	nameOfGame->setString("Sonic Classic Heroes");
	nameOfGame->setCharacterSize(50);
	nameOfGame->setPosition(screen_x / 2 - 490, 70);
	nameOfGame->setFillColor(Color::Yellow);

	menuHeading->setFont(*font1);
	menuHeading->setString("Main Menu");
	menuHeading->setCharacterSize(40);
	menuHeading->setPosition(screen_x / 2 - 190, 180);
	menuHeading->setFillColor(Color(173, 216, 230));

	copyright->setFont(*font2);
	copyright->setString("A production of Muhammad Mughees Tariq Khawaja & Muhammad Hammad Mustafa");
	copyright->setCharacterSize(20);
	copyright->setPosition(screen_x / 2 - 380, screen_y - 30);
	copyright->setFillColor(Color::White);

	layer->setFillColor(Color(0, 0, 0, 150));

	options[0] = "New Game";
	options[1] = "Continue Game";
	options[2] = "High Scores";
	options[3] = "Options";
	options[4] = "Exit Game";

	for (int i = 0; i < menuOptions; i++) {
		menu[i].setFont(*font2);
		menu[i].setString(options[i]);
		menu[i].setCharacterSize(30);
		menu[i].setFillColor(Color::White);

		box[i].setSize(Vector2f(260, 50));
		box[i].setFillColor(Color::Transparent);
		box[i].setOutlineColor(Color::White);
		box[i].setOutlineThickness(2);
		box[i].setPosition(screen_x / 2 - 150, 300 + 100 * i);
	}

	if (!isSavedStatePresent) menu[1].setFillColor(Color(128, 128, 128));

	menu[0].setPosition(screen_x / 2 - 100, 305 + 100 * 0);
	menu[1].setPosition(screen_x / 2 - 130, 305 + 100 * 1);
	menu[2].setPosition(screen_x / 2 - 105, 305 + 100 * 2);
	menu[3].setPosition(screen_x / 2 - 80, 305 + 100 * 3);
	menu[4].setPosition(screen_x / 2 - 95, 305 + 100 * 4);
}

bool MainMenu::checkForSavedGame() {
	
	fstream checkSave("savedgame.txt", ios::in);
	if (!checkSave.is_open()) return false;

	char ch = '\0';
	checkSave >> ch;

	if (ch == '\0') return false;
	return true;
}

char* MainMenu::takeNameInput(RenderWindow& window) {

	int nameIndex = 0;
	int nameSize = 17;

	char* playerName = new char[nameSize];
	for (int i = 0; i < 17; i++) playerName[i] = '\0';

	Text heading;
	heading.setFont(*font1);
	heading.setString("Register Name");
	heading.setCharacterSize(40);
	heading.setPosition(screen_x / 2 - 250, 180);
	heading.setFillColor(Color(173, 216, 230));

	Text text;
	text.setFont(*font2);
	text.setString("Enter Player Name");
	text.setCharacterSize(30);
	text.setPosition(screen_x / 2 - 132, 275);
	text.setFillColor(Color::Green);

	Text name;
	name.setFont(*font2);
	name.setCharacterSize(30);
	name.setFillColor(Color::White);
	name.setPosition(screen_x / 2 - 132, 275);

	RectangleShape box(Vector2f(400, 50));
	box.setOutlineThickness(2);
	box.setOutlineColor(Color::White);
	box.setFillColor(Color::Transparent);
	box.setPosition(screen_x / 2 - 200, 270);

	RectangleShape layer(Vector2f(screen_x, screen_y));
	layer.setFillColor(Color(0, 0, 0, 150));

	bool playerTyping = true;
	char charTyped;

	while (playerTyping) {

		Event typing;
		while (window.pollEvent(typing)) {

			if (typing.type == Event::Closed) window.close();

			if (typing.type == Event::TextEntered) {

				if (typing.text.unicode < 128 && typing.text.unicode != 32) {

					if (typing.text.unicode == 8) {

						if (playerName[0] != '\0')
							nameIndex--;
						playerName[nameIndex] = '\0';
						name.setString(playerName);
					}

					else if (typing.text.unicode == 13) {

						if (playerName[0] != '\0')
							playerTyping = false;

					}

					else if (nameIndex < 16) {

						playerName[nameIndex++] = typing.text.unicode;
						name.setString(playerName);

					}
				}
			}
		}

		window.clear();

		window.draw(*backgroundSprite);
		window.draw(layer);
		window.draw(*nameOfGame);
		window.draw(heading);
		if (playerName[0] == '\0') window.draw(text);
		window.draw(*copyright);
		window.draw(name);
		window.draw(box);

		window.display();
	}

	return playerName;
}

void MainMenu::playMusic() {
	menuMusic.setLoop(true);
	menuMusic.play();
}

void MainMenu::stopMusic() {
	menuMusic.stop();
}

void MainMenu::update(int volume) {
	menuMusic.setVolume(volume);
}