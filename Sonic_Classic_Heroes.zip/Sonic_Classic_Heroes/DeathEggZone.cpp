#include "DeathEggZone.h"
#include "Header.h"
#include "BatBrain.h"
#include"ExtraLives.h"
#include"SpecialBoost.h"

DeathEggZone::DeathEggZone(int levelNumber, Player* player1, Player* player2, Player* player3) :Level(levelNumber, player1, player2, player3) {

	friction = 0.9;
	gravity = 0.65;
	levelTime = 200;

	numofRings = 40;
	ringsLeft = numofRings;
	rings = new Rings[numofRings];

	numOfBeeBot = 2;
	numOfMotoBug = 2;
	numOfBatBrain = 2;
	numOfCrabMeat = 2;

	motoBug = new Enemy*[numOfMotoBug];   for (int i = 0; i < numOfMotoBug; i++) motoBug[i] = new MotoBug;
	beeBot = new Enemy*[numOfBeeBot];     for (int i = 0; i < numOfBeeBot; i++) beeBot[i] = new BeeBot;
	batBrain = new Enemy*[numOfBatBrain]; for (int i = 0; i < numOfBatBrain; i++) batBrain[i] = new BatBrain;
	crabMeat = new Enemy*[numOfCrabMeat]; for (int i = 0; i < numOfCrabMeat; i++) crabMeat[i] = new CrabMeat;

	numofExtraLives = 2;
	numofSpecialBoosts = 2;

		
	extraLives = new ExtraLives[numofExtraLives];
	specialBoost = new SpecialBoost[numofSpecialBoosts];


	this->levelNumber = levelNumber;
	cols = 300;
	grid = new int* [rows]; for (int i = 0; i < rows; i++) grid[i] = new int[cols];

	backgroundTexture.loadFromFile("Data/background3.png");
	backgroundSprite.setTexture(backgroundTexture);

	brick1Texture.loadFromFile("Data/brick31.png"); brick1Sprite.setTexture(brick1Texture);
	brick2Texture.loadFromFile("Data/brick32.png"); brick2Sprite.setTexture(brick2Texture);
	brick3Texture.loadFromFile("Data/brick33.png"); brick3Sprite.setTexture(brick3Texture);

	bridgeTexture.loadFromFile("Data/bridge2.png"); bridgeSprite.setTexture(bridgeTexture);
	switchTexture.loadFromFile("Data/switch2.png"); switchSprite.setTexture(switchTexture);

	spikeTexture.loadFromFile("Data/spike.png");
	spikeSprite.setTexture(spikeTexture);

	LevelMusic.openFromFile("Music/level3.mp3");
	LevelMusic.setLoop(true);
	LevelMusic.play();

	makeMap();
	deployCollectibles();
	deployEnemies();
}

DeathEggZone::~DeathEggZone() {
	for (int i = 0; i < rows; i++) delete[]grid[i];
	delete[]grid; grid = nullptr;
}

void DeathEggZone::makeMap() {

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			grid[i][j] = 0;
		}
	}

	//Labyrinth Zone has 200 columns and if we make a section of 20 columns then only 10 sections are required

	//Block 1 is for ground
	//Block 2 is for breakable wall
	//Block 3 is for platforms not on ground


	//Section 1: 0-20 columns:
	for (int i = 0; i < rows; i++) {

		for (int j = 0; j < 20; j++) {

			if (i == 0) grid[i][j] = 1;

			if (i >= 6 && i < 12)
			{
				if (j >= 12 && j <= 16) grid[i][j] = 1;

				if (i == 9)
				{
					if (j >= 7 && j <= 10) grid[i][j] = 2;
				}
			}

			else if (i >= 12)
			{
				if (j >= 12 && j <= 16) grid[i][j] = 1;
				if (j >= 0 && j <= 5) grid[i][j] = 1;
			}


		}
	}

	//Section 02: 20-40 columns:
	for (int i = 0; i < rows; i++) {

		for (int j = 20; j < 40; j++) {

			if (i == 0) grid[i][j] = 1;

			if (i >= 6 && i < 8)
			{
				if (j == 28) grid[i][j] = 1;
			}
			else if (i == 8)
			{
				if (j == 25 || j == 28 || j == 31) grid[i][j] = 1;

			}
			else if (i > 8 && i <= 10)
			{
				if (j == 22) grid[i][j] = 1;
				if (j == 25) grid[i][j] = 1;
				if (j == 28) grid[i][j] = 3;
				if (j == 31 || j == 34) grid[i][j] = 1;
				if ((i == 10) && (j == 23 || j == 24 || j == 26 || j == 26 || j == 29 || j == 30 || j == 32 || j == 33)) grid[i][j] = 8;
			}
			else if (i > 10)
			{
				grid[i][j] = 1;
			}




		}
	}

	//Section 03: 40-60 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 40; j < 60; j++) {
			if (i == 0) grid[i][j] = 1;


			else if (i == 12) { if (j >= 48 && j < 52) grid[i][j] = 1; else grid[i][j] = 4; }
		}
	}

	//Section 04: 060-080 columns:

	for (int i = 0; i < rows; i++) {
		for (int j = 60; j < 80; j++) {
			if (i == 0) grid[i][j] = 1;

			if (i == 8)
			{
				if (j >= 60 && j < 65) grid[i][j] = 2;
			}
			else if (i == 6)
			{
				if (j >= 67 && j < 69) grid[i][j] = 2;
			}

			else if (i >= 10)
			{
				if (j >= 70 && j < 80) grid[i][j] = 1;
			}

		}
	}

	//Section 05: 080 - 100 columns:

	for (int i = 0; i < rows; i++) {
		for (int j = 80; j < 100; j++) {
			if (i == 0) grid[i][j] = 1;

			if (i == 9)
			{
				if (j >= 89 && j < 100)
				{
					grid[i][j] = 1;
				}
			}

			if (i >= 10 && i < 12)
			{
				if (j >= 80 && j < 89)
				{
					grid[i][j] = 1;
				}
				if (i == 11 && j >= 89 && j < 100)
				{
					grid[i][j] = 8;
				}

			}
			else if (i >= 12)
			{
				if (j >= 80 && j < 100)
				{
					grid[i][j] = 1;
				}
			}

		}
	}
	//Section 06: 100-120 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 100; j < 120; j++) {

			if (i >= 10) grid[i][j] = 1;

		}
	}
	//Section 07: 120-140 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 120; j < 140; j++) {
			if (i == 9) { if (j == 120) grid[i][j] = 5; else if (j == 121) grid[i][j] = 7; else grid[i][j] = 1; }
			else if (i == 8) continue;
			else grid[i][j] = 1;
		}
	}
	grid[8][139] = 6; //gate
	//Section 08: 140-160 columns:

	for (int i = 0; i < rows; i++) {
		for (int j = 140; j < 160; j++) {

			if (i == 0) grid[i][j] = 1;
			
			else if (i == 3 && j != 140) grid[i][j] = 1;
			else if (i > 2 && i < 12)
			{
				if (i == 9 && j == 140) grid[i][j] = 5;
				else if (i == 10 && j == 140) grid[i][j] = 1;
				else if (j == 149 || j == 150 || j == 151) grid[i][j] = 3;
			}

			else if (i >= 12) grid[i][j] = 1;

		}
	}

	//Section 09: 160-180 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 160; j < 180; j++) {

			if (i == 0) grid[i][j] = 1;

			if (i == 3) {
				if (j >= 168 && j <= 172) grid[i][j] = 2;

			}
			else if (i == 5) {
				if (j >= 166 && j <= 168) grid[i][j] = 2;
				else if (j >= 174 && j <= 177) grid[i][j] = 2;

			}
			else if (i == 8) {
				if (j >= 164 && j <= 166) grid[i][j] = 2;

			}
			else if (i == 10) {
				if (j >= 161 && j <= 164) grid[i][j] = 2;
			}

		}
	}
	//Section 10: 180-200 columns:
	for (int i = 0; i < rows; i++) {
		for (int j = 180; j < 200; j++) {

			if (i == 0) grid[i][j] = 1;


			else if (i >= 10) {
				grid[i][j] = 1;
			}

		}
	}

	// Section 11 200 - 220

	for (int i = 0; i < rows; i++) {
		for (int j = 200; j < 220; j++) {

			if (i == 0) grid[i][j] = 1;


			else if (i == 10)
			{
				if (j >= 200 && j < 202) grid[i][j] = 1;
				if (j == 204 || j == 207 || j == 210 || j == 214 || j == 217) grid[i][j] = 1;
			}
			else if (i > 10) {
				if (j == 204 || j == 207 || j == 210 || j == 214 || j == 217) grid[i][j] = 1;

			}
			else if (i == 12) {
				if (j == 204 || j == 207 || j == 200 || j == 214 || j == 217) grid[i][j] = 1;
			}
		}
	}

	// Section 12 220 - 240
	for (int i = 0; i < rows; i++) {
		for (int j = 220; j < 240; j++) {

			if (i <= 7 && j != 220) grid[i][j] = 1;
			if (i >= 10 && i != 11) grid[i][j] = 1;
			if (i == 11) grid[i][j] = 8;
		}
	}

	// Section 12 240 - 260
	for (int i = 0; i < rows; i++) {
		for (int j = 240; j < 260; j++) {

			if (i == 9)
			{
				if (j == 242 || j == 246 || j == 248 || j == 252 || j == 254 || j == 258) grid[i][j] = 2;
			}

			else if (i == 10)
			{
				if (j >= 242 && j <= 246) grid[i][j] = 8;
				else if (j >= 248 && j <= 252) grid[i][j] = 8;
				else if (j >= 254 && j <= 258) grid[i][j] = 8;
			}
		}
	}

	//Section 14 

	for (int i = 0; i < rows; i++) {
		for (int j = 260; j < 280; j++) {

			if (i == 0) grid[i][j] = 1;
			if (i <= 6)
			{
				if (i == 3 && (j == 261 || j == 279)) grid[i][j] = 8;
				if (i == 5 || i == 4) if (j == 261 || j == 279) grid[i][j] = 1;
				if (j == 265 || j == 275) grid[i][j] = 1;
				if (i == 6 && ((j <= 264 && j >= 261) || (j > 275 || j <= 279)))
					grid[i][j] = 1;
			}
			if (i >= 10) grid[i][j] = 1;
		}
	}

	// Last Section
	for (int i = 0; i < rows; i++) {
		for (int j = 280; j < 300; j++) {

			if (i == 0) grid[i][j] = 1;
			if (i >= 10) grid[i][j] = 1;
		}
	}
}
void DeathEggZone::deployCollectibles() {
	rings[0].setPosition(12 * cellSize, 5 * cellSize);
	rings[1].setPosition(14 * cellSize, 5 * cellSize);
	rings[2].setPosition(16 * cellSize, 5 * cellSize);
	rings[3].setPosition(28 * cellSize, 4 * cellSize);
	rings[4].setPosition(31 * cellSize, 6 * cellSize);
	rings[5].setPosition(34 * cellSize, 7 * cellSize);
	rings[6].setPosition(25 * cellSize, 6 * cellSize);
	rings[7].setPosition(22 * cellSize, 7 * cellSize);
	rings[8].setPosition(61 * cellSize, 7 * cellSize);
	rings[9].setPosition(63 * cellSize, 7 * cellSize);
	rings[10].setPosition(68 * cellSize, 4 * cellSize);

	rings[11].setPosition(90 * cellSize, 6 * cellSize);
	rings[12].setPosition(92 * cellSize, 6 * cellSize);
	rings[13].setPosition(94 * cellSize, 6 * cellSize);
	rings[14].setPosition(96 * cellSize, 6 * cellSize);

	rings[15].setPosition(143 * cellSize, 1 * cellSize);
	rings[16].setPosition(146 * cellSize, 1 * cellSize);
	rings[17].setPosition(148 * cellSize, 1 * cellSize);
	rings[18].setPosition(152 * cellSize, 1 * cellSize);

	rings[19].setPosition(163 * cellSize, 9 * cellSize);
	rings[20].setPosition(165 * cellSize, 7 * cellSize);
	rings[21].setPosition(167 * cellSize, 4 * cellSize);
	rings[22].setPosition(169 * cellSize, 2 * cellSize);
	rings[23].setPosition(175 * cellSize, 4 * cellSize);

	rings[24].setPosition(262 * cellSize, 4 * cellSize);
	rings[25].setPosition(262 * cellSize, 3 * cellSize);
	rings[26].setPosition(263 * cellSize, 4 * cellSize);
	rings[27].setPosition(263 * cellSize, 3 * cellSize);

	rings[28].setPosition(242 * cellSize, 8 * cellSize);
	rings[29].setPosition(246 * cellSize, 8 * cellSize);
	rings[30].setPosition(248 * cellSize, 8 * cellSize);
	rings[31].setPosition(252 * cellSize, 8 * cellSize);
	rings[32].setPosition(254 * cellSize, 8 * cellSize);
	rings[33].setPosition(258 * cellSize, 8 * cellSize);


	rings[34].setPosition(207 * cellSize, 9 * cellSize);
	rings[35].setPosition(210 * cellSize, 9 * cellSize);
	rings[36].setPosition(214 * cellSize, 9 * cellSize);
	rings[37].setPosition(217 * cellSize, 9 * cellSize);

	rings[38].setPosition(185 * cellSize, 8 * cellSize);
	rings[39].setPosition(190 * cellSize, 8 * cellSize);

	specialBoost[0].setPosition(95*cellSize , 4*cellSize);
	specialBoost[1].setPosition(215 * cellSize, 5 * cellSize);

	extraLives[0].setPosition(155 * cellSize, 9*cellSize);
	extraLives[1].setPosition(270*cellSize , 8 * cellSize);
}
void DeathEggZone::deployEnemies() {
	motoBug[0]->setEnemy(75, 85, 9);
	motoBug[1]->setEnemy(265, 275, 9);

	beeBot[0]->setEnemy(45, 60, 5);
	beeBot[1]->setEnemy(180, 195, 7);

	crabMeat[0]->setEnemy(100, 110, 9);
	crabMeat[1]->setEnemy(285, 295, 9);

	batBrain[0]->setEnemy(140, 148, 9);
	batBrain[1]->setEnemy(280, 290, 7);
}
void DeathEggZone::levelTriggers() {

	Player* modifyPlayer = sonic;
	if (sonic->get_isPlayerActive()) modifyPlayer = sonic;
	else if (tails->get_isPlayerActive()) modifyPlayer = tails;
	else if (knuckles->get_isPlayerActive()) modifyPlayer = knuckles;

	if (!modifyPlayer) return;
	if (modifyPlayer->get_playerX() >= 89 * cellSize && modifyPlayer->get_playerX() < 100 * cellSize && !onbreakable)
	{
		breakablePath.restart();
		onbreakable = true;
	}

	if (onbreakable) {
		if (breakablePath.getElapsedTime().asMilliseconds() > 400 && breakablePath.getElapsedTime().asMilliseconds() < 500)
		{
			grid[9][89] = 0;
			grid[9][91] = 0;
		}
		if (breakablePath.getElapsedTime().asMilliseconds() > 600 && breakablePath.getElapsedTime().asMilliseconds() < 800)
		{
			grid[9][93] = 0;
			grid[9][94] = 0;
		}
		if (breakablePath.getElapsedTime().asMilliseconds() > 900 && breakablePath.getElapsedTime().asMilliseconds() < 1000) {
			grid[9][96] = 0;
			grid[9][97] = 0;
		}

	}
	else if (modifyPlayer->get_playerX() >= 222 * cellSize && modifyPlayer->get_playerX() < 240 * cellSize && !onbreakable)
	{
		breakablePath.restart();
		onbreakable = true;
	}

	if (onbreakable) {
		if (breakablePath.getElapsedTime().asMilliseconds() > 300 && breakablePath.getElapsedTime().asMilliseconds() < 500)
		{
			grid[10][223] = 0;
			grid[10][225] = 0;
		}
		if (breakablePath.getElapsedTime().asMilliseconds() > 700 && breakablePath.getElapsedTime().asMilliseconds() < 800)
		{
			grid[10][227] = 0;
			grid[10][229] = 0;
		}
		if (breakablePath.getElapsedTime().asMilliseconds() > 900 && breakablePath.getElapsedTime().asMilliseconds() < 1000) {
			grid[10][231] = 0;
			grid[10][232] = 0;
			grid[10][234] = 0;
		}

	}

	//Breakable Bridge:
	if (modifyPlayer->get_playerX() >= 38 * cellSize && modifyPlayer->get_playerX() <= 47 * cellSize &&
		modifyPlayer->get_playerY() >= 11 * cellSize - cellSize / 2 && modifyPlayer->get_playerY() <= 12 * cellSize + cellSize / 2 &&
		!isOnBridge1) {
		bridgeClock1.restart();
		isOnBridge1 = true;
	}
	else if (modifyPlayer->get_playerX() >= 50 * cellSize && modifyPlayer->get_playerX() <= 59 * cellSize &&
		modifyPlayer->get_playerY() >= 11 * cellSize - cellSize / 2 && modifyPlayer->get_playerY() <= 12 * cellSize + cellSize / 2 &&
		!isOnBridge2) {
		bridgeClock2.restart();
		isOnBridge2 = true;
	}

	//Switch and Gate:
	if (((modifyPlayer->get_playerX() >= 120 * cellSize - cellSize / 4 && modifyPlayer->get_playerX() <= 121 * cellSize + cellSize / 4) ||
		(modifyPlayer->get_playerX() >= 142 * cellSize - cellSize / 4 && modifyPlayer->get_playerX() <= 143 * cellSize + cellSize / 4)) &&
		(modifyPlayer->get_playerY() >= 8 * cellSize - cellSize / 2 && modifyPlayer->get_playerY() <= 8 * cellSize + cellSize / 2)) {
		switchClock.restart();
		isswitchOn = true;
		grid[8][139] = 0;
	}

	if (isOnBridge1 && bridgeClock1.getElapsedTime().asSeconds() > 0.5) { for (int j = 40; j < 48; j++) grid[12][j] = 0; }
	if (isOnBridge2 && bridgeClock2.getElapsedTime().asSeconds() > 0.5) { for (int j = 52; j < 60; j++) grid[12][j] = 0; }
	if (switchClock.getElapsedTime().asSeconds() > 3) { isswitchOn = false; grid[8][139] = 6; }
}